/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import controllers.AttackPhaseController;
import controllers.ReinforcementPhaseController;
import controllers.services.PhaseUpdateService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import resources.Constants;
import resources.Constants.RISKCARD;

/**
 *
 * @author mMazaheri
 */
public class Player {

    GameBoard gameBoard;

    private String playerName;

    private int numberOfArmies;
    private int reinforcementArmy;

    int numberOfCountries;

    int numberOfContinents;

    int numberOfCards;
    int sameCardsSet;
    int differentCardsSet;

    public ArrayList<String> nameOfCountries = new ArrayList<>();
    public ArrayList<String> nameOfContinents = new ArrayList<>();

    /**
     * type of card as key and number of that as value
     */
    public HashMap<RISKCARD, Integer> cardsInfo = new HashMap<>();

    /**
     * name of country as key and an ArrayList of neighboring countries
     */
    public HashMap<String, ArrayList> neighboringCountries = new HashMap<>();//country name as key and neighboursList as value

    /**
     * country name as key and its number of armies
     */
    public HashMap<String, Integer> countryArmyInfo = new HashMap<>();// country name and its num of armies

    public Player() {
    }

    public GameBoard getGameBoard() {
        return gameBoard;
    }

    public void setGameBoard(GameBoard gameBoard) {
        this.gameBoard = gameBoard;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getNumberOfArmies() {
        return numberOfArmies;
    }

    public void setNumberOfArmies(int numberOfArmies) {
        this.numberOfArmies = numberOfArmies;
    }

    public int getReinforcementArmy() {
        return reinforcementArmy;
    }

    public void setReinforcementArmy(int reinforcementArmy) {
        this.reinforcementArmy = reinforcementArmy;
    }

    public int getNumberOfCountries() {
        return numberOfCountries;
    }

    public void setNumberOfCountries(int numberOfCountries) {
        this.numberOfCountries = numberOfCountries;
    }

    public int getNumberOfContinents() {
        return numberOfContinents;
    }

    public void setNumberOfContinents(int numberOfContinents) {
        this.numberOfContinents = numberOfContinents;
    }

    public int getNumberOfCards() {
        return numberOfCards;
    }

    public void setNumberOfCards(int numberOfCards) {
        this.numberOfCards = numberOfCards;
    }

    public void setSameCardsSet(int sameCardsSet) {
        this.sameCardsSet = sameCardsSet;
    }

    public int getSameCardsSet() {
        return sameCardsSet;
    }

    public int getDifferentCardsSet() {
        return differentCardsSet;
    }

    public void setDifferentCardsSet(int differentCardsSet) {
        this.differentCardsSet = differentCardsSet;
    }

    public ArrayList<String> getNameOfCountries() {
        return nameOfCountries;
    }

    public void setNameOfCountries(ArrayList<String> nameOfCountries) {
        this.nameOfCountries = nameOfCountries;
    }

    public ArrayList<String> getNameOfContinents() {
        return nameOfContinents;
    }

    public void setNameOfContinents(ArrayList<String> nameOfContinents) {
        this.nameOfContinents = nameOfContinents;
    }

    public HashMap<RISKCARD, Integer> getCardsInfo() {
        return cardsInfo;
    }

    public void setCardsInfoInitial(HashMap<RISKCARD, Integer> cardsInfo) {
        this.cardsInfo = cardsInfo;

    }

    public void setCardsInfo(HashMap<RISKCARD, Integer> cardsInfo) {
        this.cardsInfo = cardsInfo;

        modifyNumberOfCards(cardsInfo);
    }

    public HashMap<String, ArrayList> getNeighboringCountries() {
        return neighboringCountries;
    }

    public void setNeighboringCountries(HashMap<String, ArrayList> neighboringCountries) {
        this.neighboringCountries = neighboringCountries;
    }

    public HashMap<String, Integer> getCountryArmyInfo() {
        return countryArmyInfo;
    }

    public void setCountryArmyInfo(HashMap<String, Integer> countryArmyInfo) {
        this.countryArmyInfo = countryArmyInfo;

        modifyNameOfContinents(countryArmyInfo);
        modifyNameOfCountries(countryArmyInfo);
        modifyNumberOfContinents(countryArmyInfo);
        modifyNumberOfCountries(countryArmyInfo);
        modifyNumberOfArmies(countryArmyInfo);
    }

    public void attack(GameBoard gameboard) {
        AttackPhaseController apc = new AttackPhaseController();

        PhaseUpdateService.setCurrentPhase(gameBoard, Constants.ATTACK_PHASE);
        PhaseUpdateService.setPlayerName(gameBoard, playerName);
        PhaseUpdateService.clearActions(gameBoard);
        gameBoard.stateChanged();
        apc.attackController(gameboard, this);

    }

    public void reinforcement(GameBoard gameBoard) {
        ReinforcementPhaseController rpc = new ReinforcementPhaseController();

        PhaseUpdateService.setCurrentPhase(gameBoard, Constants.REINFORCEMENT_PHASE);
        PhaseUpdateService.setPlayerName(gameBoard, getPlayerName());
        gameBoard.stateChanged();
        
        rpc.start(gameBoard, this);
        
    }

    void modifyNameOfCountries(HashMap<String, Integer> countryArmyInfo) {
        ArrayList<String> nameOfCountries = new ArrayList<String>();;
        for (String countryName : countryArmyInfo.keySet()) {
            nameOfCountries.add(countryName);
        }
        setNameOfCountries(nameOfCountries);
    }

    void modifyNumberOfCountries(HashMap<String, Integer> countryArmyInfo) {
        int numberOfCountries = 0;
        for (String countryName : countryArmyInfo.keySet()) {
            int army = countryArmyInfo.get(countryName);
            if (army > 0) {
                numberOfCountries = numberOfCountries + 1;
            }
        }
        setNumberOfCountries(numberOfCountries);
    }

    void modifyNameOfContinents(HashMap<String, Integer> countryArmyInfo) {
        ArrayList<String> nameOfContinents = new ArrayList<>();
        List<String> countryList = new ArrayList<String>();

        for (String countryName : countryArmyInfo.keySet()) {
            countryList.add(countryName);
        }

        HashMap<String, ArrayList<String>> continentCountries = gameBoard.getMap().getContinentCountries();

        for (String continentName : continentCountries.keySet()) {
            List temp = continentCountries.get(continentName);
            if (countryList.containsAll(temp)) {
                nameOfContinents.add(continentName);
            }
        }

        setNameOfContinents(nameOfContinents);
    }

    void modifyNumberOfContinents(HashMap<String, Integer> countryArmyInfo) {
        int numberOfContinents;
        ArrayList<String> nameOfContinents = new ArrayList<>();
        List<String> countryList = new ArrayList<String>();

        for (String countryName : countryArmyInfo.keySet()) {
            countryList.add(countryName);
        }

        HashMap<String, ArrayList<String>> continentCountries = gameBoard.getMap().getContinentCountries();

        for (String continentName : continentCountries.keySet()) {
            List temp = continentCountries.get(continentName);
            if (countryList.containsAll(temp)) {
                nameOfContinents.add(continentName);
            }
        }

        numberOfContinents = nameOfContinents.size();
        setNumberOfContinents(numberOfContinents);

    }

    void modifyNumberOfArmies(HashMap<String, Integer> countryArmyInfo) {
        int numberOfArmies = 0;
        for (String countryName : countryArmyInfo.keySet()) {
            numberOfArmies = numberOfArmies + countryArmyInfo.get(countryName);
        }

        setNumberOfArmies(numberOfArmies);
    }

    void modifyNumberOfCards(HashMap<RISKCARD, Integer> riskCards) {
        int numberOfCards = 0;
        for (RISKCARD cardName : riskCards.keySet()) {
            numberOfCards = numberOfCards + riskCards.get(cardName);
        }
        setNumberOfCards(numberOfCards);

        gameBoard.getPlayerRiskCards().put(playerName, numberOfCards);

    }

}
