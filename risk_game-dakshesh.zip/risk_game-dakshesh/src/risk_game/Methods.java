/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package risk_game;

import models.Player;
import models.GameBoard;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import resources.Constants.RISKCARD;

/**
 * reinforcement method and all methods needed for that are in this class
 *
 * @author mMazaheri
 */
public class Methods {

//    public GameBoard gm = new GameBoard();
//    public Scanner input = new Scanner(System.in);
////
////    public static void main(String[] args) {
////        Player player = new Player();
////        player.numOfContinents = 1;
////        player.nameOfContinents.add("Asia");
////        player.numOfCountries = 4;
////        player.nameOfCountries.add("Iran");
////        player.nameOfCountries.add("India");
////        player.nameOfCountries.add("Canada");
////        player.nameOfCountries.add("Germany");
////        player.armyInfo.put("Iran", 0);
////        player.armyInfo.put("India", 0);
////        player.armyInfo.put("Canada", 0);
////        player.armyInfo.put("Germany", 0);
////        player.numOfCards = 13;
////        GameBoard gm = new GameBoard();
////        gm.tradeInNumber = 2;
////        player.cardsInfo.put(RISKCARD.INFANTRY, 6);
////        player.cardsInfo.put(RISKCARD.CAVALRY, 3);
////        player.cardsInfo.put(RISKCARD.ARTILLERY, 4);
////        player.playerName = "Mandana";
////        reinforcement(player, gm);
////
////        // expected is 28 if player chose "n" and is 34 if chose "y"
////        
////    }
//
//    public Methods() {
//    }
//
//    /**
//     * this method is going to calculate the number of new armies as bonus for
//     * each player object and then help player to place these armies
//     *
//     * @param player
//     * @param gameBoard
//     *
//     *
//     */
//    public void reinforcement(Player player, GameBoard gameBoard) //gameBoardObj instead of turn
//    {
//        System.out.println("Reinforcement Phase for player 1:");
//        this.gm = gameBoard;
//        Scanner in = new Scanner(System.in);
//        int turn = gameBoard.tradeInNumber;
//        //turn should be a static int and ++ in each turn of game
//        int newArmies = 0;
//        if (player.numOfCountries < 9) {
//            newArmies += 3;
//        } else {
//            newArmies += (player.numOfCountries) / 3;
//        }
//        // giving armies according to number of countries
//        cardSet(player);
//        while ((player.numOfCards) >= 5) {//player can not have more than 4 catds
//            //calculate num of bonus armies according to num of turn or trade in
//            while ((player.sameCardsSet > 0) && (player.differentCardsSet > 0)) {
//                System.out.println("Wich set do you want to use for Turning In? ");
//                System.out.println("1. set of different Cards ");
//                System.out.println("2. set of same Cards ");
//                int set = in.nextInt();
//                if (set == 1) {
//                    player.differentCardsSet--;
//                    player.numOfCards -= 3;
//                    newArmies += cardTurn(turn);
//
//                }
//                if (set == 2) {
//                    player.sameCardsSet--;
//                    player.numOfCards -= 3;
//                    newArmies += cardTurn(turn);
//
//                }
//            }
//            if ((player.differentCardsSet > 0)) {
//                //System.out.println("you have " + player.differentCardsSet + " sets of different card ");
//                player.differentCardsSet--;
//                player.numOfCards -= 3;
//                newArmies += cardTurn(turn);
//            } else if ((player.sameCardsSet > 0)) {
//                //System.out.println("you have " + player.sameCardsSet + " sets of same card ");
//                player.sameCardsSet--;
//                player.numOfCards -= 3;
//                newArmies += cardTurn(turn);
//            }
//        }
//        if (((player.numOfCards) == 3) || ((player.numOfCards) == 4)) {//in case of 3 or 4 cards he can make a decision
//            if (validTurnInCard(player)) {
//                System.out.println("Do you want to Turn In Cards? y/n");
//                if (in.next().equals("y")) {
//
//                    if ((player.differentCardsSet > 0)) {
//                        player.differentCardsSet--;
//                        player.numOfCards -= 3;
//                        newArmies += cardTurn(turn);
//
//                    } else if ((player.sameCardsSet > 0)) {
//                        player.sameCardsSet--;
//                        player.numOfCards -= 3;
//                        newArmies += cardTurn(turn);
//                    }
//                    // player.numOfCards -= 3;
//
//                }
//
//            }
//        }
//        System.out.println(player.playerName + "'s number of remaining cards is " + player.numOfCards);
//        newArmies += continentDomination(player);
//        System.out.println("for this player " + newArmies + " are added");
//
//        armyPlacement(player, newArmies);
//        gameBoard.playerCountries.put(player.playerName, player.armyInfo);
//        gameBoard.playerRiskCards.put(player.playerName, player.numOfCards);
//        gameBoard.setPlayerCountries(gameBoard.playerCountries);
//        gameBoard.setPlayerRiskCards(gameBoard.playerRiskCards);
//
//        int t = gameBoard.getTradeInNumber();
//        t++;
//        gameBoard.setTradeInNumber(t);
//
//        //gameBoard.playerRiskCards ?? how exactly update it?? if he has 2 fifferent sets of cards
//        //how should we decide decrease which type???
//    }
//
//    /**
//     * *
//     * @param player
//     * @return true when player is eligible to turn in her or his cards
//     */
//    public boolean validTurnInCard(Player player) {
//        HashMap<RISKCARDS, Integer> playerCards = player.cardsInfo;
//        int a, b, c;
//        a = playerCards.get(RISKCARD.INFANTRY);
//        b = playerCards.get(RISKCARD.CAVALRY);
//        c = playerCards.get(RISKCARD.ARTILLERY);
//
//        if ((a >= 1) && (b >= 1) && (c >= 1)) {
//            return true;
//        } else if ((a >= 3) || (b >= 3) || (c >= 3)) {
//            return true;
//        }
//
//        return false;
//    }
//
//    /**
//     * gets player object and updates number of card sets of that
//     *
//     * @param player
//     */
//    public void cardSet(Player player) {
//        player.differentCardsSet = 0;
//        player.sameCardsSet = 0;
//        int cards = player.numOfCards;
//        HashMap<RISKCARDS, Integer> playerCards = player.cardsInfo;
//        int a, b, c;
//        a = playerCards.get(RISKCARD.INFANTRY);
//        b = playerCards.get(RISKCARD.CAVALRY);
//        c = playerCards.get(RISKCARD.ARTILLERY);
//        while ((a >= 1) && (b >= 1) && (c >= 1)) {
//            //creating card sets
//            player.differentCardsSet++;
//            a--;
//            b--;
//            c--;
//            cards -= 3;
////            playerCards.put(RISKCARD.INFANTRY, a);
////            playerCards.put(RISKCARD.CAVALRY, b);
////            playerCards.put(RISKCARD.ARTILLERY, c);
//        }
//        while ((a >= 3) || (b >= 3) || (c >= 3)) {
//            if (a >= 3) {
//                a -= 3;
//                player.sameCardsSet++;
//                //playerCards.put(RISKCARD.INFANTRY, a);
//                cards -= 3;
//            }
//            if (b >= 3) {
//                b -= 3;
//                player.sameCardsSet++;
//                //playerCards.put(RISKCARD.CAVALRY, b);
//                cards -= 3;
//            }
//            if (c >= 3) {
//                c -= 3;
//                player.sameCardsSet++;
//                //playerCards.put(RISKCARD.ARTILLERY, c);
//                cards -= 3;
//            }
//
//        }
//        System.out.println("player.sameCardsSet" + player.sameCardsSet);
//        System.out.println("player.differentCardsSet" + player.differentCardsSet);
//
//    }
//
//    /**
//     * this method for each turn calculates the number of armies should be added
//     *
//     * @param turn
//     * @return
//     */
//    public int cardTurn(int turn) {
//        int x = 0;
//        if (turn <= 6) {
//            switch (turn) {
//
//                case 1:
//                    x = 4;
//                    break;
//                case 2:
//                    x = 6;
//                    break;
//                case 3:
//                    x = 8;
//                    break;
//                case 4:
//                    x = 10;
//                    break;
//                case 5:
//                    x = 12;
//                    break;
//                case 6:
//                    x = 15;
//                    break;
//            }
//        }
//        if (turn > 6) {
//            x = cardTurn(turn - 1) + 5;
//        }
//
//        return x;
//    }
//
//    /**
//     * @param player
//     * @return an integer for sum of values of dominated continents
//     */
//    public int continentDomination(Player player) {
//
//        int cntValue = 0;
//        if (player.numOfContinents < 1) {
//            return 0;
//        } else {
//
//            if (player.nameOfContinents.contains("Asia")) {
//                cntValue += 7;
//            }
//            if (player.nameOfContinents.contains("Africa")) {
//                cntValue += 3;
//            }
//            if (player.nameOfContinents.contains("Australia")) {
//                cntValue += 2;
//            }
//            if (player.nameOfContinents.contains("Europe")) {
//                cntValue += 5;
//            }
//            if (player.nameOfContinents.contains("NorthAmerica")) {
//                cntValue += 5;
//            }
//            if (player.nameOfContinents.contains("SouthAmerica")) {
//                cntValue += 2;
//            }
//        }
//        return cntValue;
//
//    }
//
//    /**
//     * places all bonus armies in player's countries by asking her to select one
//     * of them each time
//     *
//     * @param player
//     * @param bonusArmies
//     */
//    public void armyPlacement(Player player, int bonusArmies) {
//        Scanner input = new Scanner(System.in);
//        int choice;
//        /**
//         * countryArmies contain player !!!
//         */
//        int countryArmies;
//
//        while (bonusArmies > 0) {
//            do {
//                System.out.println("Chose country to place one army in: ");
//                player.nameOfCountries.forEach((countryName) -> {
//                    System.out.println(player.nameOfCountries.indexOf(countryName) + "- " + countryName + "\n");
//                });
//
//                choice = input.nextInt();
//
//            } while ((choice < 0) || (choice >= player.nameOfCountries.size()));
//
//            String selectedCountry = player.nameOfCountries.get(choice);
//            System.out.println("your choice is " + choice + "- " + selectedCountry);
//            bonusArmies--;
//            System.out.println(bonusArmies);
//            countryArmies = player.armyInfo.get(selectedCountry);
//            countryArmies++;
//            player.armyInfo.replace(selectedCountry, countryArmies);
////            gm.playerCountries.put(player.playerName, player.armyInfo);
////            gm.setPlayerCountries(gm.playerCountries);
//
//            System.out.println(player.armyInfo.toString());
//
//        }
//
//    }
}



