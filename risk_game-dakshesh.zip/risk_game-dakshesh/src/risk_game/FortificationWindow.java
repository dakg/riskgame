/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package risk_game;

import models.Player;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Hasti
 * In Fortification phase, each player after attack phase could choose to move his armies or not. By using player object the armies could replace between the countries which is owned by player and are neighbour. 
 */
public class FortificationWindow extends javax.swing.JFrame {

////    private Player playerObject;
////    private String sourceCountryName;
////    private String destinationCountryName;
////    private int noOfArmies = 0;
////
////    /**
////     * Creates new form FortificationWindow
////     */
////    public FortificationWindow() {
////        initComponents();
////        String country1 = "India";
////        String country2 = "Iran";
////        String country3 = "China";
////
////        ArrayList<String> chinaNeighbours = new ArrayList<>();
////        chinaNeighbours.add(country1);
////        chinaNeighbours.add(country2);
////        ArrayList<String> indiaNeighbours = new ArrayList<>();
////        indiaNeighbours.add(country2);
////        ArrayList<String> iranNeighbours = new ArrayList<>();
////        iranNeighbours.add(country1);
////        iranNeighbours.add(country3);
////
////        ArrayList<String> countryList = new ArrayList<>();
////        countryList.add(country3);
////        countryList.add(country1);
////        countryList.add(country2);
////        HashMap<String, Integer> armyInfo = new HashMap<>();
////        armyInfo.put(country3, 4);
////        armyInfo.put(country1, 2);
////        armyInfo.put(country2, 10);
////
////        playerObject = new Player();
////        playerObject.setPlayerName("HASTI");
////        playerObject.setNameOfCountries(countryList);
////        playerObject.armyInfo = armyInfo;
////        HashMap<String, ArrayList> neighboringCountries = new HashMap<>();
////        neighboringCountries.put(country3, chinaNeighbours);
////        neighboringCountries.put(country1, indiaNeighbours);
////        neighboringCountries.put(country2, iranNeighbours);
////
////        playerObject.setNeighboringCountries(neighboringCountries);
////        JlablePlayer.setText(playerObject.getPlayerName());
////        for (String country : playerObject.getNameOfCountries()) {
////            jComboBoxSourceCountry.addItem(country);
////        }
////        jComboBoxSourceCountry.setSelectedIndex(0);
////        jComboBoxSourceCountry.addActionListener(new ActionListener() {
////            @Override
////            public void actionPerformed(ActionEvent e) {
////                
////                sourceCountryName = (String) jComboBoxSourceCountry.getSelectedItem();
////                System.out.println("selectedCountryName" + sourceCountryName);
////                  
////                int armies = armyInfo.get(sourceCountryName);
////                jLabelSourceCountryArmies.setText("" + armies);
////                ArrayList<String> neighbourCountries = neighboringCountries.get(sourceCountryName);
////                jComboBoxDestinationCountry.removeAllItems();
////                for (String neighbour : neighbourCountries) {
////                    jComboBoxDestinationCountry.addItem(neighbour);
////                }
////                jComboBoxArmies.removeAllItems();
////                for (int i = armies - 1; i > 0; i--) {
////                    jComboBoxArmies.addItem("" + i);
////                }
////            }
////        });
////        jComboBoxDestinationCountry.addActionListener(new ActionListener() {
////            @Override
////            public void actionPerformed(ActionEvent e) {
////                destinationCountryName = (String) jComboBoxDestinationCountry.getSelectedItem();
////                System.out.println("selectedCountryName" + destinationCountryName);
////                if (destinationCountryName != null) {
////                    int armies = armyInfo.get(destinationCountryName);
////                    jLabelDestinationCountryArmies.setText("" + armies);
////
////                }
////
////            }
////        });
////        jComboBoxArmies.addActionListener(new ActionListener() {
////            @Override
////            public void actionPerformed(ActionEvent e) {
////                String army = (String) jComboBoxArmies.getSelectedItem();
////                if (army != null) {
////                    noOfArmies = Integer.valueOf(army);
////                    System.out.println("Army to be moved : " + noOfArmies);
////                }
////
////            }
////        });
////
////        jButtonSend.addActionListener(new ActionListener() {
////            @Override
////            public void actionPerformed(ActionEvent e) {
////                if(sourceCountryName==null || sourceCountryName.trim().equalsIgnoreCase("") ||sourceCountryName.trim().length()<1 ){
////                    System.out.println("Please select source country.");
////                    return;
////                }
////                if(destinationCountryName==null || destinationCountryName.trim().equalsIgnoreCase("") ||destinationCountryName.trim().length()<1 ){
////                    System.out.println("Please select destination country.");
////                    return;
////                }
////                if(noOfArmies>=1){
////                  int sourceArmy = playerObject.armyInfo.get(sourceCountryName);
////                  int destinationArmy = playerObject.armyInfo.get(destinationCountryName);
////                  sourceArmy = sourceArmy - noOfArmies;
////                  destinationArmy = destinationArmy + noOfArmies;
////                  playerObject.armyInfo.put(sourceCountryName, sourceArmy);
////                  playerObject.armyInfo.put(destinationCountryName, destinationArmy);
////                  //dispose();
////                    System.out.println("source country armies: " + playerObject.armyInfo.get(sourceCountryName));
////                    System.out.println("destination country armies: " + playerObject.armyInfo.get(destinationCountryName));
////             
////                }else
////                    System.out.println("Army count is less than 1.");
////                
////            }
////        });
////        jButtonFinish.addActionListener(new ActionListener() {
////            @Override
////            public void actionPerformed(ActionEvent e) {
////                dispose();
////            }
////        });
////    }
////
////    /**
////     * This method is called from within the constructor to initialize the form.
////     * WARNING: Do NOT modify this code. The content of this method is always
////     * regenerated by the Form Editor.
////     */
////    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JlablePlayer = new javax.swing.JLabel();
        jComboBoxSourceCountry = new javax.swing.JComboBox<String>();
        jComboBoxDestinationCountry = new javax.swing.JComboBox<String>();
        jComboBoxArmies = new javax.swing.JComboBox<String>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabelSourceCountryArmies = new javax.swing.JLabel();
        jLabelDestinationCountryArmies = new javax.swing.JLabel();
        jButtonSend = new javax.swing.JButton();
        jButtonFinish = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        JlablePlayer.setText("Player");

        jComboBoxSourceCountry.setToolTipText("");

        jLabel1.setText("Source Country");

        jLabel2.setText("Destination Country");

        jLabel3.setText("Armies");

        jLabelSourceCountryArmies.setText("Army 1");

        jLabelDestinationCountryArmies.setText("Army 2");

        jButtonSend.setText("Send");

        jButtonFinish.setText("Finish");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(JlablePlayer)
                                .addGap(36, 36, 36)
                                .addComponent(jComboBoxSourceCountry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1))
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(49, 49, 49)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jComboBoxDestinationCountry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(52, 52, 52)
                                .addComponent(jComboBoxArmies, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButtonSend)
                            .addComponent(jLabelSourceCountryArmies))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(100, 100, 100)
                                .addComponent(jLabelDestinationCountryArmies))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButtonFinish)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(37, 37, 37))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(jLabel3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxSourceCountry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxDestinationCountry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxArmies, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JlablePlayer))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelSourceCountryArmies)
                    .addComponent(jLabelDestinationCountryArmies))
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonSend)
                    .addComponent(jButtonFinish))
                .addContainerGap(99, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FortificationWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FortificationWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FortificationWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FortificationWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FortificationWindow().setVisible(true);
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JlablePlayer;
    private javax.swing.JButton jButtonFinish;
    private javax.swing.JButton jButtonSend;
    private javax.swing.JComboBox<String> jComboBoxArmies;
    private javax.swing.JComboBox<String> jComboBoxDestinationCountry;
    private javax.swing.JComboBox<String> jComboBoxSourceCountry;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelDestinationCountryArmies;
    private javax.swing.JLabel jLabelSourceCountryArmies;
    // End of variables declaration//GEN-END:variables
}
