/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package risk_game;

import java.util.LinkedList;
import java.util.Stack;
import java.util.*;
import models.GameBoard;
import models.Player;
import models.GameMap;
import resources.Constants.RISKCARD;
import services.RandomGenerator;
import utilities.CircularLinkedList;

/**
 *
 * @author daksh
 */
public class GameSetup {

    public static void initializePlayers(GameBoard gameBoard, Player player[], GameMap map) {
        setPlayerNames(player);
        setPlayerCardInfo(player);
        setPlayerReinforcementArmy(player);
        setPlayerGameBoard(gameBoard, player);
    }

    public static void initializeGameBoard(GameBoard gameBoard, Player player[], GameMap map) {

        setMap(gameBoard, map);
        setNumberOfPlayers(gameBoard, player);
        setPlayerIds(gameBoard, player);
        setRiskCards(gameBoard);
        setTradeInNumber(gameBoard);
        setPlayerRiskCards(gameBoard, player);
        setPlayerCountries(gameBoard, player);
        setPlayerMapPercentage(gameBoard, player);
        setPlayerContinents(gameBoard, player);
        setPlayerNamePlayerObject(gameBoard, player);
        setPlayerStatus(gameBoard,player);
    }

    public static void setMap(GameBoard gameBoard, GameMap map) {
        gameBoard.setMap(map);
    }

    public static void setNumberOfPlayers(GameBoard gameBoard, Player player[]) {
        int numberOfPlayers = player.length;
        gameBoard.setNumberOfPlayers(numberOfPlayers);
    }

    public static void setRiskCards(GameBoard gameBoard) {

        LinkedList<RISKCARD> riskCards = new LinkedList();
        int maxPileSize = 42;

        for (int i = 0; i < maxPileSize; i++) {
            RISKCARD randomCard = RandomGenerator.randomCardGenerator();
            riskCards.add(randomCard);
        }

        gameBoard.setRiskCards(riskCards);
    }

    public static void setTradeInNumber(GameBoard gameBoard) {
        int initial = 1;
        gameBoard.setTradeInNumber(initial);
    }

    public static void setPlayerNames(Player player[]) {

        for (int i = 0; i < player.length; i++) {
            player[i].setPlayerName("Player" + " " + i);

        }

    }

    public static void setPlayerCardInfo(Player player[]) {

        for (int i = 0; i < player.length; i++) {
            HashMap<RISKCARD, Integer> cardsInfo = new HashMap<>();
            cardsInfo.put(RISKCARD.ARTILLERY, 0);
            cardsInfo.put(RISKCARD.CAVALRY, 0);
            cardsInfo.put(RISKCARD.INFANTRY, 0);

            player[i].setCardsInfoInitial(cardsInfo);

        }

    }

    private static void setPlayerRiskCards(GameBoard gameBoard, Player player[]) {
        HashMap<String, Integer> playerRiskCards = new HashMap<>();

        for (int i = 0; i < player.length; i++) {
            playerRiskCards.put(player[i].getPlayerName(), player[i].getNumberOfCards());
        }
        gameBoard.setPlayerRiskCards(playerRiskCards);
    }

    private static void setPlayerCountries(GameBoard gameBoard, Player[] player) {
        HashMap<String, HashMap<String, Integer>> playerCountries = new HashMap<>(); //player name as key and player.armyInfo as value
        for (int i = 0; i < player.length; i++) {
            HashMap<String, Integer> countryArmyInfo = new HashMap<>();
            playerCountries.put(player[i].getPlayerName(), countryArmyInfo);
        }
        gameBoard.setPlayerCountriesInitial(playerCountries);

    }

    private static void setPlayerContinents(GameBoard gameBoard, Player[] player) {
        HashMap<String, ArrayList> playerContinents = new HashMap<>();

        for (int i = 0; i < player.length; i++) {
            ArrayList<String> continents = new ArrayList<String>();
            playerContinents.put(player[i].getPlayerName(), continents);
        }
        gameBoard.setPlayerContinents(playerContinents);
    }

    private static void setPlayerMapPercentage(GameBoard gameBoard, Player[] player) {
        HashMap<String, Float> playerMapPercentage = new HashMap<>();
        for (int i = 0; i < player.length; i++) {
            playerMapPercentage.put(player[i].getPlayerName(), (float) 0.0);
        }

        gameBoard.setPlayerMapPercentage(playerMapPercentage);

    }

    private static void setPlayerReinforcementArmy(Player[] player) {

        for (int i = 0; i < player.length; i++) {
            int initialArmy = calculateArmy(player.length);
            player[i].setReinforcementArmy(initialArmy);
        }
    }

    private static int calculateArmy(int numberOfPlayer) {
        int initialArmy = 0;
        switch (numberOfPlayer) {
            case 2: {
                initialArmy = 40;
                break;
            }
            case 3: {
                initialArmy = 5;
                break;
            }
            case 4: {
                initialArmy = 30;
                break;
            }
            case 5: {
                initialArmy = 25;
                break;
            }
            case 6: {
                initialArmy = 20;
                break;
            }
        }
        return initialArmy;
    }

    private static void setPlayerIds(GameBoard gameBoard, Player[] player) {
        HashMap<Integer, String> playerNamePlayerId = new HashMap<>();
        for (int i = 0; i < player.length; i++) {
            playerNamePlayerId.put(i, player[i].getPlayerName());
        }

        gameBoard.setPlayerNamePlayerID(playerNamePlayerId);
    }

    private static void setPlayerGameBoard(GameBoard gameBoard, Player[] player) {
        for (int i = 0; i < player.length; i++) {
            player[i].setGameBoard(gameBoard);
        }
    }

    private static void setPlayerNamePlayerObject(GameBoard gameBoard, Player[] player) {
        HashMap<String, Player> playerNamePlayerObject = new HashMap<>();

        for (int i = 0; i < player.length; i++) {
            playerNamePlayerObject.put(player[i].getPlayerName(), player[i]);
        }
        gameBoard.setPlayerNamePlayerObject(playerNamePlayerObject);
    }

    private static void setActivePlayer(GameBoard gameBoard, Player player[]) {
        CircularLinkedList<Player> activePlayer = new CircularLinkedList<Player>();

        for (int i = 0; i < player.length; i++) {
            activePlayer.insertAtTail(player[i]);
        }
        gameBoard.setActivePlayer(activePlayer);

    }

    private static void setPlayerStatus(GameBoard gameBoard, Player[] player) {
        HashMap<Player,String> playerStatus= new HashMap<>();
        for(int i =0 ;i < player.length;i++){
            playerStatus.put(player[i], "ON");
        }
        gameBoard.setPlayerStatus(playerStatus);
    }
}
