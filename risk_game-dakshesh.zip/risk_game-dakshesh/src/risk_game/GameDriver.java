/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package risk_game;

import controllers.StartupPhaseController;
import models.Player;
import models.GameBoard;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JFrame;
import map.mapprocessor.InvalidMapException;
import map.mapprocessor.MapParser;
import models.GameMap;
import resources.Constants.RISKCARD;
import view.GameBoardView;
import view.GameBoardView;
import view.PhaseView;
import view.StartupPhaseView;

/**
 * this class contains all methods used for initialization of game
 *
 * @author daksh
 */
public class GameDriver {

    GameBoard gameBoard;
    GameMap map;
    Player player[];

    GameBoardView gameBoardView;
    PhaseView phaseView;

    public GameDriver(GameMap map, int numberOfPlayers) {

        //Assigning and creation of models
        initializeDataMembers(map, numberOfPlayers);

    }

    public void initializeDataMembers(GameMap map, int numberOfPlayers) {
        this.map = map;

        GameBoard gameBoard = new GameBoard(map, numberOfPlayers);
        this.gameBoard = gameBoard;
        player = new Player[numberOfPlayers];
        for (int i = 0; i < numberOfPlayers; i++) {
            player[i] = new Player();
        }

        GameBoardView gameBoardView = new GameBoardView();
        this.gameBoardView = gameBoardView;

        PhaseView phaseView = new PhaseView();
        this.phaseView = phaseView;

        this.gameBoard.addObserver(gameBoardView);
        this.gameBoard.addObserver(phaseView);
    }

    /**
     * It starts the game. Two things happen:<br> 1) It initialize the game
     * components
     * <br> 2) Runs the game
     */
    public void startGame() {
        initializeGame();
        runGame();
        System.out.println("endrun");
    }

    public void initializeGame() {
        GameSetup.initializePlayers(gameBoard, player, map);
        GameSetup.initializeGameBoard(gameBoard, player, map);
        gameBoard.stateChanged();
    }

    public void runGame() {
        gameBoardView.showView(gameBoardView);
        phaseView.showView();
        StartupPhaseController spc = new StartupPhaseController();
        spc.start(gameBoard, player, this);
//        while(spc.isOn()){
//            System.out.println("frame is on");
//        }
        System.out.println("frame is off");
        System.out.println("doen");
    }

    public void run1() {
        System.out.println("run1");
        Runnable r1 = () -> {
            player[1].reinforcement(gameBoard);
           // player[2].attack(gameBoard);
        };
        Thread t = new Thread(r1);
        t.start();

    }
}
