/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.services.AttackPhaseUpdateService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;
import java.util.stream.IntStream;
import models.GameBoard;
import models.Player;
import utilities.Country;
import view.AttackPhaseView;

/**
 * AttackPhaseController is used to update the Player Model according to the
 * AttackPhase View
 *
 * @author shivam
 */
public class AttackPhaseController {

    public static GameBoard gameboard;
    public static Player player;

    public void attackController(GameBoard gameboard, Player player) {
        this.gameboard = gameboard;
        this.player = player;
        AttackPhaseView a = new AttackPhaseView();
        a.demo(this);

    }

    /**
     * Gives the neighbor countries of the country owned by the player
     *
     * @param countryName
     * @param gameboard
     * @return
     */
    public ArrayList<String> adjacentCountries(String countryName) {

        HashMap<String, ArrayList<String>> countrywithneighbour = new HashMap<>();
        ArrayList<String> neighbours = new ArrayList<>();
        countrywithneighbour = gameboard.getMap().getCountryAndNeighbourCountries();
        neighbours = countrywithneighbour.get(countryName);
//        System.out.println(neighbours);
        // put a filter thst only shows the countries that he doesn't own
        return neighbours;
    }

    /**
     * Validates the Number of Dice Rolls selected by the player according
     * to<br>
     * the number of armies present
     *
     * @param rolls
     * @param army
     * @return
     */
    public boolean validateAttackerDiceRolls(int rolls, int army) {
        boolean status = false;
        if (army >= 3) {
            if (rolls >= 1 && rolls <= 3) {
                status = true;
            } else {
                status = false;
            }
        } else if (army < 3 && army > 1) {
            if (rolls >= 1 && rolls <= 2) {
                status = true;
            } else {
                status = false;
            }
        }
        return status;
    }

    public boolean validateDefenderDiceRolls(int rolls, int army) {
        boolean status = false;
        if (army >= 3) {
            if (rolls >= 1 && rolls <= 2) {
                status = true;
            } else {
                status = false;
            }
        } else if (army < 3 && army > 1) {
            if (rolls >= 1 && rolls <= 2) {
                status = true;
            } else {
                status = false;
            }
        } else if (army == 1) {
            if (rolls == 1) {
                status = true;
            } else {
                status = false;
            }
        }
        return status;
    }

    /**
     * Generates values of the Dice Rolled randomly
     *
     * @param rolls number of rolls selected by the player
     * @return value of dice rolled
     */
    public ArrayList<Integer> diceRollValue(int rolls) {
        ArrayList<Integer> value = new ArrayList<>();
        for (int i = 0; i < rolls; i++) {
            Random r = new Random();
            int rollvalue = r.nextInt(6) + 1;
            value.add(rollvalue);
        }
        return value;
    }

    /**
     * Compares the result of the values from the Dice Rolled by the player and
     * gives the result
     *
     * @param dicerollvalue1
     * @param dicerollvalue2
     * @return 1 if attacker wins , 2 if defender wins
     */
    public int diceRollsCompareResult(ArrayList<Integer> dicerollvalue1, ArrayList<Integer> dicerollvalue2, String sourcecountry, String targetcountry) {

        int result = 0;

        Collections.sort(dicerollvalue1, Collections.reverseOrder());
        Collections.sort(dicerollvalue2, Collections.reverseOrder());
        System.out.println(dicerollvalue1 + " " + dicerollvalue2);
        ArrayList<Integer> v1 = dicerollvalue1;
        ArrayList<Integer> v2 = dicerollvalue2;
        
        int ub1 = v1.size();
        int ub2 = v2.size();
        int ub = Math.min(ub1, ub2);
//        ArrayList<Integer> v1 = new ArrayList(dicerollvalue1);
//        ArrayList<Integer> v2 = new ArrayList(dicerollvalue2);
        int a = 0, b = 0;
        
        for (int i = 0; i < ub; i++) {
            try{
            if (v1.get(i) > v2.get(i)) {
                a++;
                updateArmyInfo(1, targetcountry);
            } else {
                b++;
                updateArmyInfo(1, sourcecountry);
            }
            }
            catch(Exception e){
                System.out.println("ggggggggggggggggggggggggggggggggggggggggggggggggggg : " + dicerollvalue2.size() + " "+ i );
                b++;
            }
        }

        if (b > 0) {
            result = 2;
        } else {
            result = 1;
        }
        return result;
    }

    /**
     * Updates the army of the country according to the dice rolls result
     *
     * @param result
     * @param sourcecountry
     * @param targetcountry
     * @return
     */
    public void updateArmyInfo(int result, String country) {
        System.out.println(country + " " + 1);
        AttackPhaseUpdateService.decrementArmy(gameboard, country, 1);
    }

    /**
     * updates the army of the target and source country according to the
     * attacker as he/she chooses the number of armies to move
     *
     * @param numberofarmytomove
     * @param sourcecountry
     * @param targetcountry
     */
    public void updateArmyInfoAttacker(int numberofarmytomove, String sourcecountry, String targetcountry) {
     //   System.out.println(sourcecountry + targetcountry + numberofarmytomove);
        AttackPhaseUpdateService.moveArmy(gameboard, sourcecountry, targetcountry, numberofarmytomove);
    }

    /**
     * Validates the number of army to be moved from source to target country
     *
     * @param sourcecountry
     * @return
     */
    public static boolean validateNumberOfArmyMove(String sourcecountry, int numberofarmy, int attackerrolls) {
        boolean status = false;
        int army = gameboard.getCountryArmy(sourcecountry);
        if (numberofarmy >= army || numberofarmy < attackerrolls) {
            status = false;
        } else if (numberofarmy >= attackerrolls) {
            if (numberofarmy > 1 && numberofarmy < army) {
                status = true;
            }

        }
        return status;
    }

    /**
     * checks whether the attacker owns the countries in the whole world or not
     *
     * @param attackingplayer
     * @return
     */
    public boolean checkWinnerOfWholeMap(String attackingplayer) {
        boolean status = false;
//        HashMap<String, HashMap<String, Integer>> playercountries = gameboard.getPlayerCountries();
//        HashMap<String, Integer> countryarmy = playercountries.get(attackingplayer);
        int ownercountries = player.getNumberOfCountries();
        int worldcountries = gameboard.getMap().getNumberOfCountries();
        if (ownercountries == worldcountries) {
            status = true;
        }
        return status;
    }

    /**
     * Computes the maximum Dice Rolls for the player which is attacking in
     * All-Out Mode
     *
     * @param sourcecountry
     * @param army
     * @return 3 if the number of army in the country is greater or equal to 3
     */
    public int getMaxDiceRollsAttacker(int army) {
        int dicerolls = 0;
        if (army > 3) {
            dicerolls = 3;
        }
        else if(army == 3){
            dicerolls = 2;
        }
        else if (army == 2) {
            dicerolls = 1;
        }
        return dicerolls;
    }

    public int getMaxDiceRollsDefender(int army) {
        int dicerolls = 0;
        if (army >= 3) {
            dicerolls = 2;
        } else if (army > 1 && army < 3) {
            dicerolls = 2;
        } else if (army == 1) {
            dicerolls = 1;
        }
        return dicerolls;
    }

    /**
     * Gives the name of the player
     *
     * @return
     */
    public String playerName() {
        return player.getPlayerName();
    }

    /**
     * Gives the name of the countries of the player
     *
     * @return
     */
    public ArrayList<String> nameOfCountries() {
        return player.getNameOfCountries();
    }

    /**
     * Gives the number of armies in the specified country
     *
     * @param country
     * @return
     */
    public int numberOfArmy(String country) {
        return gameboard.getCountryArmy(country);
    }

    /**
     * Gives the owner of the country
     *
     * @param country
     * @return
     */
    public String countryOwner(String country) {
        Country owner = gameboard.getCountryDetails(country);
        return owner.getPlayerName();
    }

    /**
     * Validates the attack from the source country by checking the number of
     * army in the country
     *
     * @param sourcecountry
     * @param targertcountry
     * @return
     */
    public boolean validSourceCountry(String country) {
        boolean status = false;
        if (player.getNameOfCountries().contains(country)) {
            if (gameboard.getCountryArmy(country) <= 1) {

                status = false;

            } else {
                status = true;
            }

        } else {
            status = false;
        }

        return status;
    }

    public boolean validTargetCountry(String sourcecountry,String targetcountry) {
        boolean status = false;
            
     
        return status;
    }

}
