/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.services.PhaseUpdateService;
import controllers.services.StartupPhaseServices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import models.GameBoard;
import models.Player;
import risk_game.GameDriver;
import view.StartupPhaseView;
import services.RandomGenerator;
import view.StartupPhaseView;
import resources.Constants;

/**
 *
 * @author daksh
 */
public class StartupPhaseController {

    GameBoard gameBoard;
    Player player[];
    StartupPhaseView startupPhaseView;

    GameDriver gameDriver;
    int totalTurns;
    int currentPlayer = 0;
    /**
     * Size of the list is the number of players in the game
     * <br> Each element is ArrayList of countries assigned to that player
     * <br> Countries to each player are assigned in random fashion
     */
    HashMap<Integer, ArrayList<String>> assignedCountries = new HashMap<>();

    HashMap<Integer, ArrayList<String>> takenCountriesMap = new HashMap<>();

    public StartupPhaseController() {

    }

    public StartupPhaseController(GameBoard gameBoard, Player player[]) {
        this.gameBoard = gameBoard;
        this.player = player;
    }

    private void initializeMembers(GameBoard gameBoard, Player[] player, GameDriver gameDriver) {
        this.gameDriver = gameDriver;
        this.gameBoard = gameBoard;
        this.player = player;
        totalTurns = player.length * player[0].getReinforcementArmy();
        System.out.println(this.toString() + totalTurns);
        startupPhaseView = new StartupPhaseView(this);

    }

    public int start(GameBoard gameBoard, Player player[], GameDriver gameDriver) {
        initializeMembers(gameBoard, player, gameDriver);
        assignedCountries = assignCountries(gameBoard, player);
        PhaseUpdateService.setCurrentPhase(gameBoard, Constants.STARTUP_PHASE);
        startupPhaseView.showView(currentPlayer);
        return 0;
    }

    public boolean isOn() {
        return startupPhaseView.isDisplayable();
    }

    private HashMap<Integer, ArrayList<String>> assignCountries(GameBoard gameBoard, Player player[]) {

        ArrayList<ArrayList<String>> initialAssignment = new ArrayList<>();
        HashMap<Integer, ArrayList<String>> assignedCountries = new HashMap<>();

        ArrayList<String> remainingCountries = new ArrayList(gameBoard.getMap().getNameOfCountries());

        int numberOfPlayers = player.length;
        //Initial equal country number to each player
        int equalCountries = remainingCountries.size() / numberOfPlayers;

        //Suppose if there are 11 countries and 3 players
        //then 9 countries will be assigned to 3 player below
        for (int i = 0; i < player.length; i++) {
            ArrayList<String> pCountries = new ArrayList<>();
            for (int j = 0; j < equalCountries; j++) {
                int randomNumber = RandomGenerator.randomNumberGenerator(0, remainingCountries.size() - 1);
                String randomCountry = remainingCountries.remove(randomNumber);
                pCountries.add(randomCountry);
            }
            initialAssignment.add(pCountries);
        }

        //there are chances that some countries are yet to be assigned
        //if numberOfPlayer is not multiple of totalNumber of countries
        //Those remaining countries assignment is done below
        if (remainingCountries.size() > 0) {
            int n = remainingCountries.size();
            //Iterate through those remaining countries and choose random player
            //give that country to that player
            for (int i = 0; i < n; i++) {
                String countryName = remainingCountries.remove(0);
                int randomPlayer = RandomGenerator.randomNumberGenerator(0, numberOfPlayers - 1);
                ArrayList<String> temp = initialAssignment.get(randomPlayer);
                temp.add(countryName);
            }
        }

        for (int i = 0; i < player.length; i++) {
            ArrayList<String> countryList = initialAssignment.get(i);
            assignedCountries.put(i, countryList);
            ArrayList empty = new ArrayList();
            takenCountriesMap.put(i, empty);

        }
        return assignedCountries;
    }

    public List<String> getList(int currentPlayer) {
        String playerName = gameBoard.getPlayerNamePlayerID().get(currentPlayer);
        List paCountries = assignedCountries.get(currentPlayer);
        List takenCountries = takenCountriesMap.get(currentPlayer);
        //    System.out.println("Before List 1 :" + paCountries);
        //    System.out.println("Before List 2 :" + takenCountries);
        List diff = (List) paCountries.stream()
                .filter(e -> !takenCountries.contains(e))
                .collect(Collectors.toList()); // (3)

        if (diff.size() == 0) {
            ArrayList<String> empty = new ArrayList();
            takenCountriesMap.put(currentPlayer, empty);
            diff = paCountries;
        }

        //    System.out.println("After List 1 :" + paCountries);
        //    System.out.println("After List 2 :" + takenCountries);
        //    System.out.println("After Difference :"+ diff );
        return diff;
    }

    public String getName(int currentPlayer) {
        String playerName = gameBoard.getPlayerNamePlayerID().get(currentPlayer);
        return playerName;
    }

    public int putArmy(int currentPlayer, String countryName) {
        String playerName = getName(currentPlayer);
        ArrayList a1 = takenCountriesMap.get(currentPlayer);
        if (a1 == null) {
            a1 = new ArrayList();
            a1.add(countryName);
        } else {
            a1.add(countryName);
        }
        System.out.println(countryName + " " + currentPlayer);

        StartupPhaseServices.updateCountryDetails(gameBoard, player[currentPlayer], playerName, countryName, 1);

        return 1;
    }

    public void updateView(int currentPlayer) {
        currentPlayer++;
        this.currentPlayer = currentPlayer;
        totalTurns--;
        System.out.println(this.toString() + totalTurns + "fa");
        if (currentPlayer >= player.length) {
            currentPlayer = 0;
        }
        if (totalTurns > 0) {
            System.out.println(currentPlayer);
            //      PhaseUpdateService.setPlayerName(gameBoard, getName(currentPlayer));
            startupPhaseView.repaint(currentPlayer);
        } else {
            startupPhaseView.dispose();
            gameDriver.run1();
        }
    }
}
