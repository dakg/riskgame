/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import models.GameBoard;
import models.Player;
import utilities.Phase;

/**
 *
 * @author daksh
 */
public class StartupPhaseServices {

    public static void updateCountryDetails(GameBoard gameBoard, Player player, String playerName, String countryName, int armyIncrement) {

        HashMap<String, HashMap<String, Integer>> playerCountries = gameBoard.getPlayerCountries();

        HashMap<String, Integer> countryArmyInfo = playerCountries.get(playerName);

        Integer armies = countryArmyInfo.get(countryName);

        if (armies == null) {
            countryArmyInfo.put(countryName, 1);
        } else if (armies != null) {
            armies = armies + armyIncrement;
            countryArmyInfo.put(countryName, armies);
        }

        int reinforcementArmy = player.getReinforcementArmy();
        int newReinforcementArmy = reinforcementArmy - 1;
        player.setReinforcementArmy(newReinforcementArmy);

        player.setCountryArmyInfo(countryArmyInfo);

        String actionInfo = playerName + " " + "puts 1 army on" + " " + countryName;

        PhaseUpdateService.setActions(gameBoard, actionInfo);
        
        gameBoard.setPlayerCountries(playerCountries);
        gameBoard.stateChanged();

    }
}
