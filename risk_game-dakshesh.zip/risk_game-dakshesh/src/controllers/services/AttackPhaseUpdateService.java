/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers.services;

import java.util.HashMap;
import models.GameBoard;
import models.Player;

/**
 *
 * @author daksh
 */
public class AttackPhaseUpdateService {

    public static void decrementArmy(GameBoard gameBoard, String countryName, int army) {
        String countryOwner = gameBoard.getCountryDetails(countryName).getPlayerName();

        Player player = gameBoard.getPlayerObjectFromPlayerName(countryOwner);

        HashMap<String, Integer> countryArmyInfo = gameBoard.getPlayerCountries().get(countryOwner);

        for (String cName : countryArmyInfo.keySet()) {
            if (cName.equals(countryName)) {
                int newArmy = countryArmyInfo.get(cName) - army;
                countryArmyInfo.put(cName, newArmy);
                break;
            }
        }
        player.setCountryArmyInfo(countryArmyInfo);
        gameBoard.setPlayerCountries(gameBoard.getPlayerCountries());

        String action = "Attack lost : " + countryName + " " + " army decremented by 1";
        PhaseUpdateService.appendAction(gameBoard, action);
        gameBoard.refresh();
        gameBoard.stateChanged();
    }

    public static void moveArmy(GameBoard gameBoard, String sourceCountry, String destinationCountry, int army) {
        String sourceOwner = gameBoard.getCountryDetails(sourceCountry).getPlayerName();
        String destinationOwner = gameBoard.getCountryDetails(destinationCountry).getPlayerName();

        Player player1 = gameBoard.getPlayerObjectFromPlayerName(sourceOwner);
        Player player2 = gameBoard.getPlayerObjectFromPlayerName(destinationOwner);

        HashMap<String, Integer> sourceCountryArmyInfo = player1.getCountryArmyInfo();

        int newArmy = sourceCountryArmyInfo.get(sourceCountry) - army;
        sourceCountryArmyInfo.put(sourceCountry, newArmy);

        sourceCountryArmyInfo.put(destinationCountry, army);

        HashMap<String, Integer> destinationCountryArmyInfo = player2.getCountryArmyInfo();
        destinationCountryArmyInfo.remove(destinationCountry);

        player1.setCountryArmyInfo(sourceCountryArmyInfo);
        player2.setCountryArmyInfo(destinationCountryArmyInfo);

        String action = "Army moved  : " + sourceCountry + " -> " + " " + destinationCountry + " " + army + "moved";
        PhaseUpdateService.appendAction(gameBoard, action);
        System.out.println(action);
        gameBoard.refresh();
        gameBoard.stateChanged();

    }
}
