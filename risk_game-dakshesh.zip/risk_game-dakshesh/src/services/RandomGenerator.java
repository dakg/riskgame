/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.Random;
import resources.Constants.RISKCARD;

/**
 *This class contains method that generates random number
 * @author daksh
 */
public class RandomGenerator {

    /**
     * This method generates a random number
     *
     * @param min Minimum value that it should generate
     * @param max Maximum value that it should generate
     * @return a random number
     */
    public static int randomNumberGenerator(int min, int max) {

        Random random = new Random();
        int range = max - min + 1;
        int n = random.nextInt(range);
        int result = min + n;
        return result;
    }
    
    public static RISKCARD randomCardGenerator(){
        RISKCARD riskCard=RISKCARD.ARTILLERY;
       
        Random random = new Random();
        int n= random.nextInt(3);
        switch(n){
            case 0:
                riskCard = RISKCARD.ARTILLERY;
                break;
            case 2 : 
                riskCard = RISKCARD.CAVALRY;
                break;
            case 3 : 
                riskCard = RISKCARD.INFANTRY;
        }
        
        return riskCard;
    }
}
