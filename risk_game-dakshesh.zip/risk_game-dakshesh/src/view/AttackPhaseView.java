/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controllers.AttackPhaseController;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author shivam
 */
public class AttackPhaseView {

    AttackPhaseController attackcontroller;
    int attackerrolls = 0, defenderrolls = 0;

    Scanner sc = new Scanner(System.in);

    public void demo(AttackPhaseController attackcontroller) {

        this.attackcontroller = attackcontroller;

        System.out.println("------ ATTACK PHASE CONTROLLER ------");

        boolean main = true;
        while (main == true) {
            int option = attackMenu();
            switch (option) {
                case 1: {
                    int result = chooseCountries();
                    if (result == 11 || result == -2 || result == 3) {
                        continue;
                    }
                }
                case 2: {
                    main = false;
                    break;
                }

            }

        }

    }

    /**
     * Player chooses the source and destination countries ; along with the
     * attack mode : 1.Attack Once 2.All Out Attack
     *
     * @return
     */
    public int chooseCountries() {
        String attacker = attackcontroller.playerName();
        System.out.println(attacker);
        System.out.println(attackcontroller.nameOfCountries());

        boolean sourcecountryvalid = true;
        String sourcecountry = null;
        while (sourcecountryvalid == true) {
            System.out.println("Enter Source country : ");
            sourcecountry = sc.next().toUpperCase().trim();

            if (attackcontroller.validSourceCountry(sourcecountry)) {
                sourcecountryvalid = false;
                break;
            }
            else{
                System.out.println("Cannot choose " + sourcecountry + " as number of armies : " + attackcontroller.numberOfArmy(sourcecountry));
            }

        }

        System.out.println(" Neighbour Countries ");
        ArrayList<String> neighbour = attackcontroller.adjacentCountries(sourcecountry);
        System.out.println(neighbour);

        String targetcountry = null;
        boolean targetcountryvalid = true;
        while (targetcountryvalid == true) {
            System.out.println("Enter Target country : ");
            targetcountry = sc.next().toUpperCase().trim();

            if (neighbour.contains(targetcountry)) {
                targetcountryvalid = false;
                break;
            }
            else{
                System.out.println("Invalid Target country");
            }

        }

        boolean modeloop = true;
        while (modeloop == true) {
            int mode = attackType();

            while (true) {
                if (validMode(mode)) {
                    break;
                } else {
                    System.out.println("Please enter proper mode !");
                }
            }

            if (mode == 1) {
                int result = manualAttack(sourcecountry, targetcountry);
                if (result == 1) {
                    if (attackcontroller.numberOfArmy(targetcountry) >= 1) {
                        continue;
                    } else {
                        moveArmy(sourcecountry, targetcountry, attackerrolls, attacker);
                        return 11;
                    }
                } else if (result == 2) {
                    if (attackcontroller.validSourceCountry(sourcecountry)) {
                        continue;
                    } else {
                        return -2;
                    }

                }
            } else if (mode == 2) {
                int result = allOut(sourcecountry, targetcountry);
                if (result == 1) {
                    moveArmy(sourcecountry, targetcountry, attackerrolls, attacker);
                    return 11;
                } else if (result == -2) {
                    System.out.println("Attack lost ! Cannot attack from " + sourcecountry);
                    return -2;
                }

            } else if (mode == 3) {
                return 3;
            }

        }
        return 0;
    }

    /**
     * Attack is performed in the All Out Mode
     *
     * @param sourcecountry
     * @param targetcountry
     * @return 1 if attacker wins the attack and -2 if defender wins
     */
    public int allOut(String sourcecountry, String targetcountry) {
        int result = autoAttack(sourcecountry, targetcountry);
        if (result == 1) {
            return 1;
        } else if (result == -2) {
            return -2;
        }
        return result;
    }

    /**
     * Automatically makes the attack run until the defender has 0 armies left
     * or the attacker loses and cannot attack further
     *
     * @param sourcecountry
     * @param targetcountry
     * @return 1 if attacker wins the attack and -2 if the defender wins the
     * attack
     */
    public int autoAttack(String sourcecountry, String targetcountry) {
        while (true) {
            attackerrolls = attackcontroller.getMaxDiceRollsAttacker(attackcontroller.numberOfArmy(sourcecountry));
            ArrayList<Integer> dicerollvalue1 = attackcontroller.diceRollValue(attackerrolls);
            System.out.println("Value of Dice Rolls for attacker : " + dicerollvalue1);

            defenderrolls = attackcontroller.getMaxDiceRollsDefender(attackcontroller.numberOfArmy(targetcountry));
            ArrayList<Integer> dicerollvalue2 = attackcontroller.diceRollValue(defenderrolls);
            System.out.println("Value of Dice Rolls for defender : " + dicerollvalue2);

            int r = doAttack(sourcecountry, targetcountry, dicerollvalue1, dicerollvalue2);
            if (r == 1) {
                if (attackcontroller.numberOfArmy(targetcountry) >= 1) {
                    continue;
                } else {
                    return 1;
                }
            } else if (r == 2) {
                if (attackcontroller.numberOfArmy(sourcecountry) > 1) {
                    continue;
                } else {
                    return -2;
                }
            }

        }
    }

    /**
     * <b> Asks the attacker the number of armies to be moved from the source
     * country to the destination country</b>
     * and also checks whether the attacker is the owner of the whole world or
     * not
     *
     * @param sourcecountry
     * @param targetcountry
     * @param attackerrolls
     * @param attacker
     */
    public void moveArmy(String sourcecountry, String targetcountry, int attackerrolls, String attacker) {

        boolean correctarmy = true;
        int army = 0;
        while (correctarmy == true) {
            System.out.println("Enter the number of armies you want to move from " + sourcecountry + " to " + targetcountry + " : ");
            army = sc.nextInt();
            if (attackcontroller.validateNumberOfArmyMove(sourcecountry, army, attackerrolls)) {
                correctarmy = false;
            } else {
                System.out.println("Invalid number of Army selected ");
            }

        }
        attackcontroller.updateArmyInfoAttacker(army, sourcecountry, targetcountry);
        if (attackcontroller.checkWinnerOfWholeMap(attacker)) {
           
            System.out.println("Player" + attacker + " wins the Game !");
       
        }

    }

    /**
     * Displays the Main Attack Phase Menu and asks for the player choice
     *
     * @return 1 if the player chooses to attack and 2 if the player chooses to
     * exit
     */
    public int attackMenu() {
        System.out.println("1.) ATTACK");
        System.out.println("2.) EXIT");

        System.out.println("Enter your choice : ");
        int choice = sc.nextInt();

        return choice;
    }

    /**
     * Displays the type of the attack the player wants to play with
     *
     * @return 1 if the player wants to attack once and 2 if the player wants to
     * attack with all out mode and 3 if the player wants to close the attack
     */
    public int attackType() {

        System.out.println("1. ATTACK-ONCE");
        System.out.println("2. ALL-OUT");
        System.out.println("3. CLOSE THIS ATTACK");

        System.out.println("Enter your choice : ");
        int choice = sc.nextInt();

        return choice;
    }

    /**
     * Checks whether the attack type mode selected by the player is valid or
     * not
     *
     * @param mode
     * @return true if the mode selected is valid and false if the mode selected
     * is invalid
     */
    public boolean validMode(int mode) {
        boolean status = false;
        if (mode == 1 || mode == 2 || mode == 3) {
            status = true;
        } else {
            status = false;
        }
        return status;
    }

    /**
     * Player attacks with attack once type ; player is asked for the dice rolls
     * which gets validated after which the value of the dice rolls are
     * generated randomly , using which the winner of the attack is declared
     *
     * @param sourcecountry
     * @param targetcountry
     * @return 1 if attacker wins the attack and 2 if defender wins the attack
     */
    public int manualAttack(String sourcecountry, String targetcountry) {
        showArmy(sourcecountry);
        showArmy(targetcountry);

        boolean rolla = true, rollb = true;
        while (rolla == true) {
            System.out.println("Player :" + attackcontroller.countryOwner(sourcecountry) + "  Select Number of Dice rolls : ");
            attackerrolls = sc.nextInt();
            if (attackcontroller.validateAttackerDiceRolls(attackerrolls, attackcontroller.numberOfArmy(sourcecountry)) == true) {
                rolla = false;

            } else {
                System.out.println("Invalid Rolls Selected");
            }

        }

        while (rollb == true) {
            System.out.println(attackcontroller.countryOwner(targetcountry) + " Selects Number of Dice rolls : ");
            defenderrolls = sc.nextInt();
            if (attackcontroller.validateDefenderDiceRolls(defenderrolls, attackcontroller.numberOfArmy(targetcountry))) {
                rollb = false;
            } else {
                System.out.println("Invalid Rolls Selected");
            }
        }

        ArrayList<Integer> attackerdicerollvalue1 = attackcontroller.diceRollValue(attackerrolls);
        System.out.println("Value of Dice Rolls for attacker : " + attackerdicerollvalue1);

        ArrayList<Integer> defenderdicerollvalue2 = attackcontroller.diceRollValue(defenderrolls);
        System.out.println("Value of Dice Rolls for defender : " + defenderdicerollvalue2);

        int r = doAttack(sourcecountry, targetcountry, attackerdicerollvalue1, defenderdicerollvalue2);
        if (r == 1) {
            System.out.println(attackcontroller.countryOwner(sourcecountry) + " won the attack ");
            return 1;
        } else if (r == 2) {
            System.out.println(attackcontroller.countryOwner(targetcountry) + " won the attack ");
            return 2;
        }
        return r;
    }

    /**
     * Declares the result of the winner of the attack by comparing the dice
     * value rolled by the attacker and defender
     *
     * @param sourcecountry
     * @param targetcountry
     * @param attackerdicerollvalue
     * @param defenderdicerollvalue
     * @return 1 if attacker wins the attack and 2 if defender wins the attack
     */
    public int doAttack(String sourcecountry, String targetcountry, ArrayList<Integer> attackerdicerollvalue, ArrayList<Integer> defenderdicerollvalue) {
        return attackcontroller.diceRollsCompareResult(attackerdicerollvalue, defenderdicerollvalue, sourcecountry, targetcountry);

    }

    /**
     * Displays the army in the country
     *
     * @param country
     */
    public void showArmy(String country) {
        System.out.println("Number of Armies in :" + country + attackcontroller.numberOfArmy(country));
    }

}
