/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controllers.ReinforcementPhaseController;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author daksh
 */
public class ReinforcementPhaseView {

    ReinforcementPhaseController rpc;

    public void showView(ReinforcementPhaseController rpc) {
        this.rpc = rpc;
        System.out.println("------------Reinforcement Phase Started---------------");
        System.out.println("Calculating number of Armies.....");
        System.out.println("Reinforcements : ");
        System.out.println("Reinforcement Because of Countries you own :");
        System.out.println("Number of countries : " + Integer.toString(rpc.getNumberOfCountries()));
        System.out.println("Reinforcement : " + Integer.toString(rpc.calculateReinforcementFromCountry()));
        System.out.println("Reinforcement Because of Continents you own : ");
        System.out.println("Number of Continents : " + Integer.toString(rpc.getNumberOfContinents()));
        System.out.println("Reinforcement : " + Integer.toString(rpc.calculateReinforcementFromContinents()));

    }

    public int[] getCardChoice() {
        Scanner sc = new Scanner(System.in);
        int c[] = new int[3];
        System.out.println("Enter Artillery card number:");
        c[0] = sc.nextInt();
        System.out.println("Enter Cavalry card number:");
        c[1] = sc.nextInt();
        System.out.println("Enter Infantry card number:");
        c[2] = sc.nextInt();

        return c;
    }

    public String getCountryName() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Country Name");
        String countryName = sc.next();
        return countryName.trim().toUpperCase();
    }

    public int getMoveNumber() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter army to move");
        int moveNumber = sc.nextInt();
        return moveNumber;
    }

}
