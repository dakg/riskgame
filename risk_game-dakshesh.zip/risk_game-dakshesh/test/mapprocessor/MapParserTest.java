/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapprocessor;

import map.mapprocessor.InvalidMapException;
import map.mapprocessor.MapParser;
import java.util.HashMap;
import models.GameMap;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author daksh
 */
public class MapParserTest {

    GameMap expectedMap;
    
    public MapParserTest() {
    }

    @Before
    public void setUp() {
        HashMap<String, String> worldMap = new HashMap<String, String>();
        worldMap.put("INDIA", "INDIA,0,0,ASIA,SYDNEY");
        worldMap.put("SYDNEY", "SYDNEY,0,0,AUSTRALIA,INDIA");
        HashMap<String, Integer> continentValue = new HashMap<String, Integer>();
        continentValue.put("ASIA", 2);
        continentValue.put("AUSTRALIA", 1);
        expectedMap = new GameMap(worldMap, continentValue);
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of parseMap method, of class MapParser.
     */
    @org.junit.Test
    public void testParseMap() throws InvalidMapException {
        System.out.println("parseMap");
        String filePath = "C:\\Users\\daksh\\Desktop\\test_maps\\k.map";
        GameMap actualMap = MapParser.parseMap(filePath);
        System.out.println(actualMap.toString());
        System.out.println(expectedMap.toString());
        assertEquals(actualMap,expectedMap);
 //       assertThat(actualMap).isEqualToComparingFieldByField(expectedMap);
    }
    
//
//    /**
//     * Test of getContinentValue method, of class MapParser.
//     */
//    @org.junit.Test
//    public void testGetContinentValue() {
//        System.out.println("getContinentValue");
//        String filePath = "";
//        HashMap<String, Integer> expResult = null;
//        HashMap<String, Integer> result = MapParser.getContinentValue(filePath);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

}
