/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package map.maprules;

import java.util.HashMap;
import models.GameMap;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author daksh
 */
public class MapValidatorRulesTest {
    
    public MapValidatorRulesTest() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of isWorldMapEmpty method, of class MapValidatorRules.
     */
    @Test
    public void testIsWorldMapEmpty() {
        System.out.println("isWorldMapEmpty");
        GameMap map = new GameMap();
        HashMap<String,String> worldMap = new HashMap<>();
        worldMap.put("INDIA", "INDIA,0,0,ASIA,ENGLAND");
        map
        boolean expResult = false;
        boolean result = MapValidatorRules.isWorldMapEmpty(map);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isContinentValueEmpty method, of class MapValidatorRules.
     */
    @Test
    public void testIsContinentValueEmpty() {
        System.out.println("isContinentValueEmpty");
        GameMap map = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.isContinentValueEmpty(map);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidNumberOfConnectionsOfEachCountry method, of class MapValidatorRules.
     */
    @Test
    public void testIsValidNumberOfConnectionsOfEachCountry() {
        System.out.println("isValidNumberOfConnectionsOfEachCountry");
        GameMap map = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.isValidNumberOfConnectionsOfEachCountry(map);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidNumberOfCountries method, of class MapValidatorRules.
     */
    @Test
    public void testIsValidNumberOfCountries() {
        System.out.println("isValidNumberOfCountries");
        GameMap map = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.isValidNumberOfCountries(map);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidNumberOfContinents method, of class MapValidatorRules.
     */
    @Test
    public void testIsValidNumberOfContinents() {
        System.out.println("isValidNumberOfContinents");
        GameMap map = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.isValidNumberOfContinents(map);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkConnectionWithItself method, of class MapValidatorRules.
     */
    @Test
    public void testCheckConnectionWithItself() {
        System.out.println("checkConnectionWithItself");
        int[][] worldAdjancencyMatrix = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.checkConnectionWithItself(worldAdjancencyMatrix);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isGraphConnected method, of class MapValidatorRules.
     */
    @Test
    public void testIsGraphConnected() {
        System.out.println("isGraphConnected");
        int[][] a = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.isGraphConnected(a);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isWorldConnected method, of class MapValidatorRules.
     */
    @Test
    public void testIsWorldConnected() {
        System.out.println("isWorldConnected");
        GameMap map = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.isWorldConnected(map);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isContinentsInterConnected method, of class MapValidatorRules.
     */
    @Test
    public void testIsContinentsInterConnected() {
        System.out.println("isContinentsInterConnected");
        GameMap map = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.isContinentsInterConnected(map);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isContinentsInnerConnected method, of class MapValidatorRules.
     */
    @Test
    public void testIsContinentsInnerConnected() {
        System.out.println("isContinentsInnerConnected");
        GameMap map = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.isContinentsInnerConnected(map);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isAnyContinentEmpty method, of class MapValidatorRules.
     */
    @Test
    public void testIsAnyContinentEmpty() {
        System.out.println("isAnyContinentEmpty");
        GameMap map = null;
        boolean expResult = false;
        boolean result = MapValidatorRules.isAnyContinentEmpty(map);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
