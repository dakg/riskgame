/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers.services;

import java.util.HashMap;
import models.GameBoard;
import models.Player;
import resources.Constants.RISKCARD;

/**
 *
 * @author daksh
 */
public class ReinforcementPhaseUpdateService {

    public static void changeCardInfo(GameBoard gameBoard, Player player, int choice[]) {
        HashMap<RISKCARD, Integer> cardInfo = player.getCardsInfo();

        int newCard1 = cardInfo.get(RISKCARD.ARTILLERY) - choice[0];
        int newCard2 = cardInfo.get(RISKCARD.CAVALRY) - choice[1];
        int newCard3 = cardInfo.get(RISKCARD.INFANTRY) - choice[2];

        cardInfo.put(RISKCARD.ARTILLERY, newCard1);
        cardInfo.put(RISKCARD.CAVALRY, newCard2);
        cardInfo.put(RISKCARD.INFANTRY, newCard3);

        player.setCardsInfo(cardInfo);
        player.stateChanged();
        gameBoard.stateChanged();

        //No of cards are automatically changed in gameBoard through player model
    }

    public static void updateTradeInNumber(GameBoard gameBoard) {
        int newTradeInNumber = gameBoard.getTradeInNumber() + 1;
    }

    public static void updateReinforcementArmy(Player player, int reinforcement) {
        player.setReinforcementArmy(reinforcement);
    }

    public static void updateCountryArmyInfo(GameBoard gameBoard, Player player, String countryName, int incrementArmy) {
        HashMap<String, Integer> countryArmyInfo = player.getCountryArmyInfo();
        int oldArmy = countryArmyInfo.get(countryName);
        int newArmy = oldArmy + incrementArmy;
        countryArmyInfo.put(countryName, newArmy);

        player.setCountryArmyInfo(countryArmyInfo);
        gameBoard.refresh();
        gameBoard.stateChanged();

    }
    
    public static void updateActions(GameBoard gameBoard,Player player,String action){
        PhaseUpdateService.setActions(gameBoard, action);
    }
}
