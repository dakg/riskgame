/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers.services;

import java.util.HashMap;
import models.GameBoard;
import models.Player;

/**
 *
 * @author daksh
 */
public class FortificationPhaseUpdateService {

    public static void moveArmy(GameBoard gameBoard, Player player, String sourceCountry, String destinationCountry, int moveArmy) {
        HashMap<String, Integer> countryArmyInfo = player.getCountryArmyInfo();

        int army1 = countryArmyInfo.get(sourceCountry);
        int army2 = countryArmyInfo.get(destinationCountry);

        countryArmyInfo.put(sourceCountry, army1 - moveArmy);
        countryArmyInfo.put(destinationCountry, army2 + moveArmy);

        player.setCountryArmyInfo(countryArmyInfo); 
        
        gameBoard.refresh();
    }
    
    public static void updateActions(GameBoard gameBoard,Player player,String action){
        PhaseUpdateService.setActions(gameBoard, action);
    }
}
