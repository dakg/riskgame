/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.services.PhaseUpdateService;
import controllers.services.ReinforcementPhaseUpdateService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import models.GameBoard;
import models.Player;
import resources.Constants;
import resources.Constants.RISKCARD;
import view.CardExchangeView;
import view.ReinforcementPhaseView;

/**
 *
 * @author daksh
 */
public class ReinforcementPhaseController {

    public static GameBoard gameBoard;
    public static Player player;
    ReinforcementPhaseView reinforcementPhaseView;
    CardExchangeView cardExchangeView;
    boolean tradedFlag;

    int reinforcement = 0;

    public void start(GameBoard gameBoard, Player player) {
        this.gameBoard = gameBoard;
        this.player = player;
        reinforcementPhaseView = new ReinforcementPhaseView();
        cardExchangeView = new CardExchangeView();
        player.addObserver(cardExchangeView);
        
        reinforcementPhaseView.showView(this);
        reinforcement = reinforcement + calculateReinforcementFromCountry();
        reinforcement = reinforcement + calculateReinforcementFromContinents();

        cardExchangeView.showView(this);


        ReinforcementPhaseUpdateService.updateReinforcementArmy(player, reinforcement);
        System.out.println("Total reinforcement " + reinforcement);
        updateActions("Total reinforcement " + reinforcement);
        performMove();

        if (tradedFlag) {
            ReinforcementPhaseUpdateService.updateTradeInNumber(gameBoard);
        }

    }

    public void compulsoryTradeIn() {
        System.out.println("Checking compulsory trade in ....");
        updateActions("Checking compulsory trade in ....");
        if (player.getNumberOfCards() >= 5) {
            System.out.println("You have to do compulsory trade in.");
            updateActions("You have to do compulsory trade in.");
            reinforcement = reinforcement + doCompulsoryTradeIn();
            System.out.println("Compulsory trade in finished");
            updateActions("Compulsory trade in finished");
            tradedFlag = true;
        } else {
            System.out.println("You dont have to do compulsory trade in ");
            updateActions("You dont have to do compulsory trade in ");
        }
    }

    public void manualTradeIn() {
        System.out.println("Checking Manual trade in....");
        if (checkEligilibityForTradeIn()) {
            System.out.println("You are eligible to trade in :");
            System.out.println("You want to trade in or not: 1 for yes / 2 for no");
            int tradeInChoice;
            while (true) {
                tradeInChoice = cardExchangeView.getTradeInChoice();
                if (validTradeInChoice(tradeInChoice)) {
                    break;
                }
            }
            if (tradeInChoice == 1) {
                reinforcement = reinforcement + doNormalTradeIn();
                tradedFlag = true;
            } else {
                System.out.println("Exited!!");
            }
        } else {
            System.out.println("You are not eligible to trade");
        }
    }

    public int doNormalTradeIn() {
        int army = 0;

        System.out.println(player.getCardsInfo());
        int choice[] = cardExchangeView.getCardChoice();

        if (isValidChoice(choice)) {
            if (checkTradeInPossible(choice)) {
                army = army + doTradeIn(choice);
                System.out.println("Trading Completed");
                ReinforcementPhaseUpdateService.changeCardInfo(gameBoard, player, choice);
            } else {
                System.out.println("Invalid choice : Trade In Not possible");
            }
        } else {
            System.out.println("Invalid Choices");
        }
        return army;
    }

    public int doCompulsoryTradeIn() {
        int army = 0;

        while (player.getNumberOfCards() >= 5) {
            System.out.println(player.getCardsInfo());

            int choice[] = cardExchangeView.getCardChoice();

            if (isValidChoice(choice)) {

                if (checkTradeInPossible(choice)) {

                    army = army + doTradeIn(choice);
                    System.out.println("Trade in completed");
                    ReinforcementPhaseUpdateService.changeCardInfo(gameBoard, player, choice);
                } else {
                    System.out.println("Trade In Not possible");
                }

            } else {
                System.out.println("Invalid Choices");
            }
        }
        return army;

    }

    public int doCompulsoryTradeIn(int choice[]) {
        int army = 0;

        while (player.getNumberOfCards() >= 5) {
            System.out.println(player.getCardsInfo());

            if (isValidChoice(choice)) {

                if (checkTradeInPossible(choice)) {

                    army = army + doTradeIn(choice);
                    ReinforcementPhaseUpdateService.changeCardInfo(gameBoard, player, choice);

                } else {
                    System.out.println("Trade In Not possible");
                }

            } else {
                System.out.println("Invalid Choices");
            }
        }
        return army;

    }

    public int getNumberOfCountries() {
        return player.getNumberOfCountries();
    }

    public int getNumberOfContinents() {
        return player.getNumberOfContinents();
    }

    public int calculateReinforcementFromContinents() {
        int continentReinforcement = 0;
        int continentNumber = player.getNumberOfContinents();
        if (continentNumber > 0) {
            ArrayList<String> nameOfContinents = player.getNameOfContinents();
            for (int i = 0; i < nameOfContinents.size(); i++) {
                int continentValue = gameBoard.getMap().getContinentValue(nameOfContinents.get(i));
                continentReinforcement = continentReinforcement + continentValue;
            }

            return continentReinforcement;
        } else {
            return 0;
        }

    }

    public int calculateReinforcementFromCountry() {

        int countryReinforcement;
        int countryNumber = player.getNumberOfCountries();

        if (countryNumber > 9) {
            countryReinforcement = countryNumber / 3;
        } else {
            countryReinforcement = 3;
        }

        return countryReinforcement;
    }

    private boolean isValidChoice(int choice[]) {

        try {
            int c1 = choice[0];
            int c2 = choice[1];
            int c3 = choice[2];

            int c = c1 + c2 + c3;

            if (c == 3) {
                boolean b1 = (c1 == 3 && c2 == 0 && c3 == 0);
                boolean b2 = (c1 == 0 && c2 == 3 && c3 == 0);
                boolean b3 = (c1 == 0 && c2 == 0 && c3 == 3);

                if (b1 || b2 || b3) {
                    return true;
                } else if (c1 == 1 && c2 == 1 && c3 == 1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }

        } catch (ArrayIndexOutOfBoundsException e) {
            return false;
        }

    }

    private boolean checkTradeInPossible(int[] choice) {
        HashMap<RISKCARD, Integer> cardsInfo = player.getCardsInfo();
        int ca1 = cardsInfo.get(RISKCARD.ARTILLERY) != null ? cardsInfo.get(RISKCARD.ARTILLERY) : 0;
        int ca2 = cardsInfo.get(RISKCARD.CAVALRY) != null ? cardsInfo.get(RISKCARD.CAVALRY) : 0;
        int ca3 = cardsInfo.get(RISKCARD.INFANTRY) != null ? cardsInfo.get(RISKCARD.INFANTRY) : 0;

        if (choice[0] <= ca1 && choice[1] <= ca2 && choice[2] <= ca3) {
            return true;
        } else {
            return false;
        }
    }

    private int doTradeIn(int[] choice) {
        int tradeInNumber = gameBoard.getTradeInNumber();
        int armyValue = tradeInNumber * 5;
        return armyValue;
    }

    private boolean checkEligilibityForTradeIn() {
        HashMap<RISKCARD, Integer> cardsInfo = player.getCardsInfo();
        int ca1 = cardsInfo.get(RISKCARD.ARTILLERY) != null ? cardsInfo.get(RISKCARD.ARTILLERY) : 0;
        int ca2 = cardsInfo.get(RISKCARD.CAVALRY) != null ? cardsInfo.get(RISKCARD.CAVALRY) : 0;
        int ca3 = cardsInfo.get(RISKCARD.INFANTRY) != null ? cardsInfo.get(RISKCARD.INFANTRY) : 0;

        if (ca1 >= 1 && ca2 >= 1 && ca3 >= 1) {
            return true;
        } else if (ca1 >= 3) {
            return true;
        } else if (ca2 >= 3) {
            return true;
        } else if (ca3 >= 3) {
            return true;
        } else {
            return false;
        }
    }

    private void performMove() {
        while (reinforcement > 0) {
            System.out.println("Please select Country name:");
            System.out.println(player.getCountryArmyInfo());
            String countryName;
            while (true) {
                countryName = reinforcementPhaseView.getCountryName();
                if (isValidCountryName(countryName)) {
                    break;
                } else {
                    System.out.println("Invalid Country Name");
                }
            }
            int moveNumber;
            while (true) {
                moveNumber = reinforcementPhaseView.getMoveNumber();
                if (moveNumber <= reinforcement) {
                    break;
                }
            }
            ReinforcementPhaseUpdateService.updateCountryArmyInfo(gameBoard, player, countryName, moveNumber);
            reinforcement = reinforcement - moveNumber;
            System.out.println("Reinforcement yet to be placed : " + reinforcement);
            ReinforcementPhaseUpdateService.updateReinforcementArmy(player, reinforcement);
        }
    }

    private boolean isValidCountryName(String countryName) {
        if (player.getNameOfCountries().contains(countryName.trim().toUpperCase())) {
            return true;
        } else {
            return false;
        }
    }

    private void updateActions(String action) {
        ReinforcementPhaseUpdateService.updateActions(gameBoard, player, action);
    }

    private boolean validTradeInChoice(int tradeInChoice) {
        if (tradeInChoice == 1 || tradeInChoice == 2) {
            return true;
        } else {
            return false;
        }
    }
    
    public Player getPlayer(){
        return player;
    }

}
