/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controllers.AttackPhaseController;
import java.util.ArrayList;
import java.util.Scanner;
import services.RandomGenerator;

/**
 *
 * @author shivam
 */
public class AttackPhaseView {

    AttackPhaseController attackController;
    int attackerRolls = 0, defenderRolls = 0;

    Scanner sc = new Scanner(System.in);

    public void demo(AttackPhaseController attackcontroller) {

        this.attackController = attackcontroller;

        System.out.println("------ ATTACK PHASE CONTROLLER ------");

        boolean main = true;
        if (attackcontroller.canAttack()) {
            while (main == true && attackcontroller.canAttack()) {
                int option = attackMenu();
                switch (option) {
                    case 1: {
                        int result = chooseCountries();
                        if (result == 11 || result == -2 || result == 3) {
                            continue;
                        }
                    }
                    case 2: {
                        main = false;
                        break;
                    }

                }

            }

            if (main == false) {

                System.out.println("Attack Phase ended!!");
            } else {
                System.out.println("You cannot attack any more");
            }

        } else {
            System.out.println("You cannot attack!! Attack Phase ended!!");
        }

    }

    /**
     * Player chooses the source and destination countries ; along with the
     * attack mode : 1.Attack Once 2.All Out Attack
     *
     * @return
     */
    public int chooseCountries() {
        String attacker = attackController.playerName();
        System.out.println(attacker);
        System.out.println(attackController.nameOfCountries());

        boolean sourceCountryValid = true;
        String sourceCountry = null;
        while (sourceCountryValid == true) {
            System.out.println("Enter Source country : ");
            //  sourceCountry = sc.next().toUpperCase().trim();
            sourceCountry = RandomGenerator.getMyCountry(attackController.getPlayer());
            System.out.println(sourceCountry);
            if (attackController.isValidSourceCountry(sourceCountry)) {
                sourceCountryValid = false;
                break;
            } else {
                System.out.println("Cannot choose " + sourceCountry);
            }

        }

        System.out.println(" Neighbour Countries ");
        ArrayList<String> neighbour = attackController.adjacentCountries(sourceCountry);
        System.out.println(neighbour);

        String targetCountry = null;
        boolean targetCountryValid = true;
        while (targetCountryValid == true) {
            System.out.println("Enter Target country : ");
            //   targetCountry = sc.next().toUpperCase().trim();
            targetCountry = RandomGenerator.getNeighbourCOuntry(attackController.getGameBoard(), sourceCountry);
            System.out.println(targetCountry);
            if (attackController.isValidTargetCountry(targetCountry) && neighbour.contains(targetCountry)) {
                targetCountryValid = false;
                break;
            } else {
                System.out.println("Invalid Target country");
            }

        }

        boolean modeloop = true;
        while (modeloop == true) {
            int mode = attackType();

            while (true) {
                if (isValidMode(mode)) {
                    break;
                } else {
                    System.out.println("Please enter proper mode !");
                }
            }

            if (mode == 1) {
                int result = manualAttack(sourceCountry, targetCountry);
                if (result == 1) {
                    if (attackController.numberOfArmy(targetCountry) >= 1) {
                        continue;
                    } else {
                        moveArmy(sourceCountry, targetCountry, attackerRolls, attacker);
                        return 11;
                    }
                } else if (result == 2) {
                    if (attackController.isValidSourceCountry(sourceCountry)) {
                        continue;
                    } else {
                        return -2;
                    }

                }
            } else if (mode == 2) {
                int result = allOut(sourceCountry, targetCountry);
                if (result == 1) {
                    moveArmy(sourceCountry, targetCountry, attackerRolls, attacker);
                    return 11;
                } else if (result == -2) {
                    System.out.println("Attack lost ! Cannot attack from " + sourceCountry);
                    return -2;
                }

            } else if (mode == 3) {
                return 3;
            }

        }
        return 0;
    }

    /**
     * Attack is performed in the All Out Mode
     *
     * @param sourceCountry
     * @param targetCountry
     * @return 1 if attacker wins the attack and -2 if defender wins
     */
    public int allOut(String sourcecountry, String targetcountry) {
        int result = autoAttack(sourcecountry, targetcountry);
        if (result == 1) {
            return 1;
        } else if (result == -2) {
            return -2;
        }
        return result;
    }

    /**
     * Automatically makes the attack run until the defender has 0 armies left
     * or the attacker loses and cannot attack further
     *
     * @param sourceCountry
     * @param targetCountry
     * @return 1 if attacker wins the attack and -2 if the defender wins the
     * attack
     */
    public int autoAttack(String sourceCountry, String targetCountry) {
        while (true) {
            attackerRolls = attackController.getMaxDiceRollsAttacker(attackController.numberOfArmy(sourceCountry));
            ArrayList<Integer> diceRollValue1 = attackController.diceRollValue(attackerRolls);
            System.out.println("Value of Dice Rolls for attacker : " + diceRollValue1);

            defenderRolls = attackController.getMaxDiceRollsDefender(attackController.numberOfArmy(targetCountry));
            ArrayList<Integer> diceRollValue2 = attackController.diceRollValue(defenderRolls);
            System.out.println("Value of Dice Rolls for defender : " + diceRollValue2);

            int r = doAttack(sourceCountry, targetCountry, diceRollValue1, diceRollValue2);
            if (r == 1) {
                if (attackController.numberOfArmy(targetCountry) >= 1) {
                    continue;
                } else {
                    return 1;
                }
            } else if (r == 2) {
                if (attackController.numberOfArmy(sourceCountry) > 1) {
                    continue;
                } else {
                    return -2;
                }
            }

        }
    }

    /**
     * <b> Asks the attacker the number of armies to be moved from the source
     * country to the destination country</b>
     * and also checks whether the attacker is the owner of the whole world or
     * not
     *
     * @param sourceCountry
     * @param targetCountry
     * @param attackerRolls
     * @param attacker
     */
    public void moveArmy(String sourceCountry, String targetCountry, int attackerRolls, String attacker) {

        boolean correctArmy = true;
        int army = 0;
        while (correctArmy == true) {

            System.out.println("Enter the number of armies you want to move from " + sourceCountry + " to " + targetCountry + " : ");
            //   army = sc.nextInt();
            army = RandomGenerator.randomNumberGenerator(1, attackController.getPlayer().getCountryArmyInfo().get(sourceCountry) - 1);
            System.out.println(army);
            if (attackController.isValidNumberOfArmyMove(sourceCountry, army, attackerRolls)) {
                System.out.println("Checking for the flag");
                if (attackController.getFlag() == true) {
                    System.out.println("Reaching the statement");
                    attackController.updateRiskCard();
                    attackController.setFlag();
                }

                correctArmy = false;
            } else {
                System.out.println("Invalid number of Army selected ");
            }

        }
        attackController.updateArmyInfoAttacker(army, sourceCountry, targetCountry);
        if (attackController.checkWinnerOfWholeMap()) {

            System.out.println("Player" + attacker + " wins the Game !");

        }

    }

    /**
     * Displays the Main Attack Phase Menu and asks for the player choice
     *
     * @return 1 if the player chooses to attack and 2 if the player chooses to
     * exit
     */
    public int attackMenu() {
        System.out.println("1.) ATTACK");
        System.out.println("2.) EXIT");

        System.out.println("Enter your choice : ");
//        int choice = sc.nextInt();
        int choice = RandomGenerator.randomNumberGenerator(1, 2);
        System.out.println(choice);
        return choice;
    }

    /**
     * Displays the type of the attack the player wants to play with
     *
     * @return 1 if the player wants to attack once and 2 if the player wants to
     * attack with all out mode and 3 if the player wants to close the attack
     */
    public int attackType() {

        System.out.println("1. ATTACK-ONCE");
        System.out.println("2. ALL-OUT");
        System.out.println("3. CLOSE THIS ATTACK");

        System.out.println("Enter your choice : ");
        //    int choice = sc.nextInt();
        int choice = RandomGenerator.randomNumberGenerator(1, 3);
        System.out.println(choice);
        return choice;
    }

    /**
     * Checks whether the attack type mode selected by the player is valid or
     * not
     *
     * @param mode
     * @return true if the mode selected is valid and false if the mode selected
     * is invalid
     */
    public boolean isValidMode(int mode) {
        boolean status = false;
        if (mode == 1 || mode == 2 || mode == 3) {
            status = true;
        } else {
            status = false;
        }
        return status;
    }

    /**
     * Player attacks with attack once type ; player is asked for the dice rolls
     * which gets validated after which the value of the dice rolls are
     * generated randomly , using which the winner of the attack is declared
     *
     * @param sourceCountry
     * @param targetCountry
     * @return 1 if attacker wins the attack and 2 if defender wins the attack
     */
    public int manualAttack(String sourceCountry, String targetCountry) {
        showArmy(sourceCountry);
        showArmy(targetCountry);

        boolean rolla = true, rollb = true;
        while (rolla == true) {
            System.out.println("Player :" + attackController.countryOwner(sourceCountry) + "  Select Number of Dice rolls : ");
            //  attackerRolls = sc.nextInt();
            attackerRolls = RandomGenerator.randomNumberGenerator(1, 3);
            System.out.println(attackerRolls);
            if (attackController.isValidAttackerDiceRolls(attackerRolls, attackController.numberOfArmy(sourceCountry)) == true) {
                rolla = false;

            } else {
                System.out.println("Invalid Rolls Selected");
            }

        }

        while (rollb == true) {
            System.out.println(attackController.countryOwner(targetCountry) + " Selects Number of Dice rolls : ");
            //   defenderRolls = sc.nextInt();
            defenderRolls = RandomGenerator.randomNumberGenerator(1, 2);
            System.out.println(defenderRolls);
            if (attackController.isValidDefenderDiceRolls(defenderRolls, attackController.numberOfArmy(targetCountry))) {
                rollb = false;
            } else {
                System.out.println("Invalid Rolls Selected");
            }
        }

        ArrayList<Integer> attackerDiceRollValue1 = attackController.diceRollValue(attackerRolls);
        System.out.println("Value of Dice Rolls for attacker : " + attackerDiceRollValue1);

        ArrayList<Integer> defenderDiceRollValue2 = attackController.diceRollValue(defenderRolls);
        System.out.println("Value of Dice Rolls for defender : " + defenderDiceRollValue2);

        int r = doAttack(sourceCountry, targetCountry, attackerDiceRollValue1, defenderDiceRollValue2);
        if (r == 1) {
            System.out.println(attackController.countryOwner(sourceCountry) + " won the attack ");
            return 1;
        } else if (r == 2) {
            System.out.println(attackController.countryOwner(targetCountry) + " won the attack ");
            return 2;
        }
        return r;
    }

    /**
     * Declares the result of the winner of the attack by comparing the dice
     * value rolled by the attacker and defender
     *
     * @param sourceCountry
     * @param targetCountry
     * @param attackerDiceRollValue
     * @param defenderDiceRollValue
     * @return 1 if attacker wins the attack and 2 if defender wins the attack
     */
    public int doAttack(String sourceCountry, String targetCountry, ArrayList<Integer> attackerDiceRollValue, ArrayList<Integer> defenderDiceRollValue) {
        return attackController.diceRollsCompareResult(attackerDiceRollValue, defenderDiceRollValue, sourceCountry, targetCountry);

    }

    /**
     * Displays the army in the country
     *
     * @param country
     */
    public void showArmy(String country) {
        System.out.println("Number of Armies in :" + country + attackController.numberOfArmy(country));
    }

}
