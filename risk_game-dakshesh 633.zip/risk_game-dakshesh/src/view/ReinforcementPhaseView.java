/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controllers.ReinforcementPhaseController;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import services.RandomGenerator;

/**
 *
 * @author daksh
 */
public class ReinforcementPhaseView {

    ReinforcementPhaseController rpc;

    public void showView(ReinforcementPhaseController rpc) {
        this.rpc = rpc;
        System.out.println("------------Reinforcement Phase Started---------------");
        System.out.println("Calculating number of Armies.....");
        System.out.print("Reinforcement Because of Countries you own :");
        System.out.print("Number of countries : " + Integer.toString(rpc.getNumberOfCountries()));
        System.out.println("Reinforcement : " + Integer.toString(rpc.calculateReinforcementFromCountry()));
        System.out.print("Reinforcement Because of Continents you own : ");
        System.out.print("Number of Continents : " + Integer.toString(rpc.getNumberOfContinents()));
        System.out.println("Reinforcement : " + Integer.toString(rpc.calculateReinforcementFromContinents()));

    }

    public int[] getCardChoice() {
        Scanner sc = new Scanner(System.in);
        int c[] = new int[3];
        System.out.println("Enter Artillery card number:");
     //   c[0] = sc.nextInt();
        System.out.println("Enter Cavalry card number:");
     //   c[1] = sc.nextInt();
        System.out.println("Enter Infantry card number:");
     //   c[2] = sc.nextInt();
        c = RandomGenerator.getCardChoice();
        System.out.println(c);
        return c;
    }

    public String getCountryName() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Country Name");
       // String countryName = sc.next();
        String countryName = RandomGenerator.getMyCountry(rpc.getPlayer());
        System.out.println(countryName);
        return countryName.trim().toUpperCase();
    }

    public int getMoveNumber() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter army to move");
     //   int moveNumber = sc.nextInt();
       int moveNumber = RandomGenerator.randomNumberGenerator(1, rpc.getPlayer().getReinforcementArmy());
        System.out.println(moveNumber);
        return moveNumber;
    }

}
