/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package map.mapprocessor;

/**
 *
 * @author daksh
 */
public class InvalidMapException extends Exception {
     private String msg;

    InvalidMapException(String msg) {
        this.msg = msg;
    }

    public String getMessage() {
        return msg;
    }

}
