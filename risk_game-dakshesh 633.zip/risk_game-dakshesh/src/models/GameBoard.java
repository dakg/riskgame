/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.Stack;
import models.GameMap;
import resources.Constants.*;
import utilities.Country;

/**
 * GameBoard Class stores all the information about the game.
 * <br> For Eg: numberOfPlayers, activePlayers, information about which country
 * is owned by which player and how many number of army in that country.
 *
 * @author mMazaheri
 */
public class GameBoard extends Observable {

    /**
     * Game would be played on this map
     */
    GameMap map;

    /**
     * Total Active number of players
     */
    private int numberOfPlayers;

    /**
     * It contain playerId as key and playerName as value
     */
    private HashMap<Integer, String> playerIdPlayerName = new HashMap<>();

    private HashMap<Player, String> playerStatus = new HashMap<>();

    private HashMap<String, Player> playerNamePlayerObject = new HashMap<>();
    /**
     * Pile of RiskCard in GameBoard.
     */
    LinkedList<RISKCARD> riskCards = new LinkedList<>();

    /**
     * It records the trade in number.So it helps in maintaining current trade
     * in number
     */
    private int tradeInNumber;

    /**
     * It gives information about which player owns how many risk cards It
     * contains:
     * <br> key : Player Name
     * <br> value : Number of RiskCard he owns
     */
    private HashMap<String, Integer> playerRiskCards = new HashMap<>();// player name and num of her risk cards

    /**
     * HashMap containing playerName as key and playerCountries HashMap as
     * value. playerCountries HashMap contain :
     * <br> key : Country name
     * <br> value : Army in that Country
     */
    private HashMap<String, HashMap<String, Integer>> playerCountries = new HashMap<>(); //player name as key and player.armyInfo as value

    /**
     * It gives information about which player owns how many continents It
     * contains :
     * <br> key : player name
     * <br> key : ArrayList of continents he owns. null :if he doesn't own any
     * continents
     */
    private HashMap<String, ArrayList> playerContinents = new HashMap<>();

    /**
     * It gives information about which player has what % of the world It
     * contains :
     * <br>key : player name
     * <br>value : map % he owns
     * <br>formula : ((countries he own) / (total countries)) * 100
     */
    private HashMap<String, Float> playerMapPercentage = new HashMap<>();

    /**
     * It stores the number of armies a player has in all countries he own
     * <br> key : player name
     * <br> value : Total Number of armies
     */
    private HashMap<String, Integer> playerArmies = new HashMap<>();
    /**
     * Stores information about the current ongoing phase;
     */
    private Phase currentPhaseDetails = new Phase();

    public GameBoard(GameMap map, int numberOfPlayer) {
        this.map = map;
        this.numberOfPlayers = numberOfPlayers;
    }

    public void setMap(GameMap map) {
        this.map = map;

    }

    public HashMap<Player, String> getPlayerStatus() {
        return playerStatus;
    }

    public void setPlayerStatus(HashMap<Player, String> playerStatus) {
        this.playerStatus = playerStatus;
    }

    public void setNumberOfPlayers(int numberOfPlayers) {
        this.numberOfPlayers = numberOfPlayers;

    }

    public void setPlayerNamePlayerID(HashMap<Integer, String> playerIdPlayerName) {
        this.playerIdPlayerName = playerIdPlayerName;
    }

    public void setRiskCards(LinkedList<RISKCARD> riskCards) {
        this.riskCards = riskCards;

    }

    public void setTradeInNumber(int tradeInNumber) {
        this.tradeInNumber = tradeInNumber;

    }

    public void setPlayerRiskCards(HashMap<String, Integer> playerRiskCards) {
        this.playerRiskCards = playerRiskCards;

    }

    public void setPlayerCountriesInitial(HashMap<String, HashMap<String, Integer>> playerCountries) {
        this.playerCountries = playerCountries;

        setNumberOfPlayers(this.playerCountries);
        setPlayerContinentsFromPlayerCountries(this.playerCountries);
        setPlayerMapPercentageFromPlayerCountries(this.playerCountries);
        setPlayerArmiesFromPlayerCountries(this.playerCountries);

    }

    public void setPlayerCountries(HashMap<String, HashMap<String, Integer>> playerCountries) {

        this.playerCountries = playerCountries;

        setPlayerStatusFromPlayerCountries(this.playerCountries);
        setNumberOfPlayers(this.playerCountries);
        setPlayerContinentsFromPlayerCountries(this.playerCountries);
        setPlayerMapPercentageFromPlayerCountries(this.playerCountries);
        setPlayerArmiesFromPlayerCountries(this.playerCountries);
        
    }

    void setNumberOfPlayers(HashMap<String, HashMap<String, Integer>> playerCountries) {

        this.numberOfPlayers = playerCountries.size();;
    }

    public void setPlayerContinents(HashMap<String, ArrayList> playerContinents) {
        this.playerContinents = playerContinents;

    }

    public void setPlayerMapPercentage(HashMap<String, Float> playerMapPercentage) {
        this.playerMapPercentage = playerMapPercentage;

    }

    public void setPlayerArmies(HashMap<String, Integer> playerArmies) {
        this.playerArmies = playerArmies;
    }

    public void setCurrentPhaseDetails(Phase currentPhaseDetails) {
        this.currentPhaseDetails = currentPhaseDetails;
    }

    /**
     * It calculates the name of the continents owned by the player and updates
     * the {@link #playerContinents}
     *
     * @param playerCountries
     */
    void setPlayerContinentsFromPlayerCountries(HashMap<String, HashMap<String, Integer>> playerCountries) {

        HashMap<String, ArrayList> playerContinents = new HashMap();

        for (String playerName : playerCountries.keySet()) {

            ArrayList<String> a = new ArrayList<String>();

            HashMap<String, Integer> countryArmyInfo = playerCountries.get(playerName);

            //    if (countryArmyInfo != null) {
            List<String> countryList = new ArrayList<String>();

            for (String countryName : countryArmyInfo.keySet()) {
                countryList.add(countryName);
            }

            HashMap<String, ArrayList<String>> continentCountries = map.getContinentCountries();
            for (String continentName : continentCountries.keySet()) {
                List temp = continentCountries.get(continentName);
                if (countryList.containsAll(temp)) {
                    a.add(continentName);
                }
            }
            playerContinents.put(playerName, a);
//            } 
//            else {
//                playerContinents.put(playerName, a);
//            }
        }

        this.playerContinents = playerContinents;

    }

    /**
     * It calculates the map percentage owned by the player from
     * {@link #playerCountries}
     * <br> and sets {@link #playerMapPercentage}
     *
     * @param playerCountries
     */
    void setPlayerMapPercentageFromPlayerCountries(HashMap<String, HashMap<String, Integer>> playerCountries) {

        HashMap<String, Float> playerMapPercentage = new HashMap();

        for (String playerName : playerCountries.keySet()) {
            HashMap<String, Integer> countryArmyInfo = playerCountries.get(playerName);
            //      System.out.println(countryArmyInfo);
            if (countryArmyInfo != null) {
                int countries = countryArmyInfo.size();
                int totalCountries = map.getNumberOfCountries();
                //       System.out.println("Total countries : " + totalCountries);
                //       System.out.println(playerName + " " + countries);
                Float percentage = (float) ((float) countries / totalCountries) * 100;

                playerMapPercentage.put(playerName, percentage);
                //        System.out.println("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr" + playerMapPercentage);
            } else {
                playerMapPercentage.put(playerName, Float.NaN);
            }
        }

        this.playerMapPercentage = playerMapPercentage;

    }

    public void setPlayerArmiesFromPlayerCountries(HashMap<String, HashMap<String, Integer>> playerCountries) {
        HashMap<String, Integer> playerArmies = new HashMap<>();

        for (String playerName : playerCountries.keySet()) {
            int totalArmy = 0;
            HashMap<String, Integer> countryArmyInfo = playerCountries.get(playerName);
            if (!countryArmyInfo.isEmpty()) {
                for (String countryName : countryArmyInfo.keySet()) {
                    int army = countryArmyInfo.get(countryName) == null ? 0 : countryArmyInfo.get(countryName);
                    totalArmy = totalArmy + army;
                }
            } else {
                totalArmy = 0;
            }
            playerArmies.put(playerName, totalArmy);
        }

        this.playerArmies = playerArmies;
    }

    public void setPlayerStatusFromPlayerCountries(HashMap<String, HashMap<String, Integer>> playerCountries) {
        ArrayList<String> removeNames = new ArrayList();
        ArrayList<String> addNames = new ArrayList();
        for (String playerName : playerCountries.keySet()) {
            HashMap<String, Integer> temp = playerCountries.get(playerName);
            if (temp.isEmpty()) {
                removeNames.add(playerName);
            } else {
                addNames.add(playerName);
            }
        }

        ArrayList<Player> removePlayers = new ArrayList<>();
        ArrayList<Player> addPlayers = new ArrayList<>();

        for (int i = 0; i < removeNames.size(); i++) {
            Player p = getPlayerObjectFromPlayerName(removeNames.get(i));
            removePlayers.add(p);
        }

        for (int i = 0; i < addNames.size(); i++) {
            Player p = getPlayerObjectFromPlayerName(addNames.get(i));
            addPlayers.add(p);
        }

        for (int i = 0; i < removePlayers.size(); i++) {
            //     this.activePlayer.
            playerStatus.put(removePlayers.get(i), "OFF");
        }

        for (int i = 0; i < addPlayers.size(); i++) {
            playerStatus.put(addPlayers.get(i), "ON");
        }

        setPlayerStatus(playerStatus);
    }

    /**
     * Notifies observer that the state of the object has been changed
     */
    public void stateChanged() {
        setChanged();
        notifyObservers(this);
    }

    /**
     *
     * @return {@link #map}
     */
    public GameMap getMap() {
        return map;
    }

    /**
     *
     * @return {@link #numberOfPlayers}
     */
    public int getNumberOfPlayers() {
        return numberOfPlayers;
    }

    /**
     *
     * @return {@link #playerIdPlayerName}
     */
    public HashMap<Integer, String> getPlayerNamePlayerID() {
        return playerIdPlayerName;
    }

    /**
     *
     * @return {@link #riskCards}
     */
    public LinkedList<RISKCARD> getRiskCards() {
        return riskCards;
    }

    /**
     *
     * @return {@link #tradeInNumber}
     */
    public int getTradeInNumber() {
        return tradeInNumber;
    }

    /**
     *
     * @return {@link #playerRiskCards}
     */
    public HashMap<String, Integer> getPlayerRiskCards() {
        return playerRiskCards;
    }

    /**
     *
     * @return {@link #playerCountries}
     */
    public HashMap<String, HashMap<String, Integer>> getPlayerCountries() {
        return playerCountries;
    }

    /**
     *
     * @return {@link #playerContinents}
     */
    public HashMap<String, ArrayList> getPlayerContinents() {
        return playerContinents;
    }

    /**
     *
     * @return {@link #playerMapPercentage}
     */
    public HashMap<String, Float> getPlayerMapPercentage() {
        return playerMapPercentage;
    }

    public HashMap<String, Integer> getPlayerArmies() {
        return playerArmies;
    }
    
    

    public Phase getCurrentPhaseDetails() {
        return currentPhaseDetails;
    }

    public HashMap<Integer, String> getPlayerIdPlayerName() {
        return playerIdPlayerName;
    }

    public void setPlayerIdPlayerName(HashMap<Integer, String> playerIdPlayerName) {
        this.playerIdPlayerName = playerIdPlayerName;
    }

    public HashMap<String, Player> getPlayerNamePlayerObject() {
        return playerNamePlayerObject;
    }

    public void setPlayerNamePlayerObject(HashMap<String, Player> playerNamePlayerObject) {
        this.playerNamePlayerObject = playerNamePlayerObject;
    }

    public Player getPlayerObjectFromPlayerName(String playerName) {
        for (String pName : playerNamePlayerObject.keySet()) {
            if (pName.equals(playerName)) {
                Player player = playerNamePlayerObject.get(playerName);
                return player;
            }
        }
        return null;
    }

    /**
     * It gives the information regarding country
     *
     * @param countryName name of the country
     * @return {@link utilities.Country}
     * <br> null if no country with such name
     */
    public Country getCountryDetails(String countryName) {
        Country c = new Country();
        c.setPlayerName("No owner");
        c.setAmries(0);
        try {
            for (String playerName : playerCountries.keySet()) {
                HashMap<String, Integer> armyInfo = playerCountries.get(playerName);
                for (String cName : armyInfo.keySet()) {
                    if (cName.equals(countryName)) {
                        int noOfArmy = armyInfo.get(cName);
                        if (noOfArmy >= 0) {
                            c.setPlayerName(playerName);
                            c.setAmries(noOfArmy);
                            return c;
                        }
                    }
                }
            }
            return c;
        } catch (NullPointerException np) {
            System.out.println(np.toString());
            return c;
        }
    }

    /**
     * This checks whether the game is over or not
     *
     * @return true if there is only 1 player otherwise false
     */
    public boolean isGameOver() {
        int activePlayers = 0;
        HashMap<Player, String> activePlayer = getPlayerStatus();
        for (Player p : activePlayer.keySet()) {
            String status = activePlayer.get(p);
            if (status.equalsIgnoreCase("ON")) {
                activePlayers++;
            }
        }
        if (activePlayers == 1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method gets name of country and returns number of armies in that
     * country
     *
     * @param countryName
     * @return
     */
    public int getCountryArmy(String countryName) {
        try {
            for (String playerName : playerCountries.keySet()) {
                HashMap<String, Integer> armyInfo = playerCountries.get(playerName);
                for (String cName : armyInfo.keySet()) {
                    if (cName.equals(countryName)) {
                        int noOfArmy = armyInfo.get(cName);
                        return noOfArmy;
                    }

                }
            }
            return 0;
        } catch (NullPointerException np) {
            //    System.out.println(np.toString());
            return 0;
        }
    }

    public void refresh() {
        setPlayerCountries(playerCountries);
        setPlayerRiskCards(playerRiskCards);
    }

    public void printGameBoard() {
        System.out.println(playerCountries);
        System.out.println(playerContinents);
        System.out.println(playerMapPercentage);
    }

    public String getWinner() {
        if (isGameOver()) {
            HashMap<Player, String> activePlayer = getPlayerStatus();
            for (Player p : activePlayer.keySet()) {
                String status = activePlayer.get(p);
                if (status.equalsIgnoreCase("on")) {
                    return p.getPlayerName();
                }
            }
            return "";
        } else {
            return "";
        }
    }

    public boolean isActivePlayer(Player p) {
        String status = playerStatus.get(p);
        if (status.equalsIgnoreCase("on")) {
            return true;
        } else {
            return false;
        }
    }
    

}
