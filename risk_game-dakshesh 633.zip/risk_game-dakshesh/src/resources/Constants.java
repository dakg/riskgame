package resources;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * CON
 * @author daksh
 */
public abstract class Constants {
    
    /**
     * Contains an empty String
     */
    public static final String EMPTY_STRING = "";
    
    public static final String STARTUP_PHASE = "Startup Phase";
    public static final String REINFORCEMENT_PHASE = "Reinforcement Phase";
    public static final String ATTACK_PHASE = "Attack Phase";
    public static final String FORTIFICATION_PHASE = "Fortification Phase";
    
    public enum RISKCARD{ INFANTRY , CAVALRY , ARTILLERY};
}
