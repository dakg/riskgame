This maps contains same number of countries and continents.
They are modified version of  map nancy.ie invalid characters in map 
Aim : To check map parsing
