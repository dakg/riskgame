/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controllers.FortificationPhaseController;
import java.util.Scanner;
import services.RandomGenerator;

/**
 *
 * @author daksh
 */
public class FortificationPhaseView {

    FortificationPhaseController fpc;
    public void showView(FortificationPhaseController fpc) {
        this.fpc = fpc;
        System.out.println("-------------------Fortificatin Phase-------------------");
    }

    public String getCountryName() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Country Name");
      //  String countryName = sc.next();
        String countryName = RandomGenerator.getMyCountry(fpc.getPlayer());
        System.out.println(countryName);
        return countryName.trim().toUpperCase();
    }

    public int getArmyNumber() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter army to move");
      //  int moveNumber = sc.nextInt();
        String sourceCountry = fpc.getSourceCountry();
        int moveNumber = RandomGenerator.randomNumberGenerator(1, fpc.getPlayer().getCountryArmyInfo().get(sourceCountry) - 1);
        System.out.println(moveNumber);
        return moveNumber;
    }

    public int getFortificationSignal() {
        Scanner sc = new Scanner(System.in);
      //  int signal = sc.nextInt();
        int signal = RandomGenerator.randomNumberGenerator(1, 2);
        System.out.println(signal);
        return signal;
    }

}
