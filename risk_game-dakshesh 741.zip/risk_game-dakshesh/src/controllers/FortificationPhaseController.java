/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.util.HashMap;
import models.GameBoard;
import models.Player;
import utilities.Country;
import view.FortificationPhaseView;

/**
 *
 * @author daksh
 */
public class FortificationPhaseController {

    GameBoard gameBoard;
    Player player;
    FortificationPhaseView fpv;
    String sourceCountry;
    String destinationCountry;
    int armyNumber;

    public void startFortification(GameBoard gameBoard, Player player) {
        this.gameBoard = gameBoard;
        this.player = player;

        fpv = new FortificationPhaseView();
        fpv.showView(this);
        if (canFortify()) {
            System.out.println("Do you want to fortify? 1 for yes/ 2 for no");
            int signal;
            while (true) {
                signal = fpv.getFortificationSignal();
                if (validSignal(signal)) {
                    break;
                }
            }
            if (signal == 1) {
                doFortification();
            } else {
                System.out.println("Fortification ended");
            }
        } else {
            System.out.println("Fortification cannot be done!!");
        }
    }

    private void doFortification() {

        while (true) {
            System.out.println("Select source country :");
            System.out.println(player.getNameOfCountries());
            sourceCountry = fpv.getCountryName();
            if (isValidSourceCountry(sourceCountry)) {
                break;
            }
        }

        while (true) {
            System.out.println("Select Destination country :");
            System.out.println(player.getNameOfCountries());
            destinationCountry = fpv.getCountryName();
            if (isValidDestinationCountry(destinationCountry)) {
                break;
            } else {
                System.out.println("Not a valid Destination country");
            }
        }

        while (true) {
            System.out.println("Enter number of armies to move:");
            armyNumber = fpv.getArmyNumber();
            if (isValidArmyNumber(armyNumber)) {
                break;
            }
        }

    }

    private boolean isValidSourceCountry(String sourceCountry) {
        if (player.getNameOfCountries().contains(sourceCountry)) {
            if (player.getCountryArmyInfo().get(sourceCountry) > 1) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private boolean isValidDestinationCountry(String destinationCountry) {
        if (player.getNameOfCountries().contains(sourceCountry)) {
            if (!sourceCountry.equals(destinationCountry)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private boolean isValidArmyNumber(int armyNumber) {
        Country country = gameBoard.getCountryDetails(sourceCountry);
        int army = country.getAmries();
        if (army - armyNumber >= 1) {
            return true;
        } else {
            return false;
        }
    }

    private boolean validSignal(int signal) {
        if (signal == 1 || signal == 2) {
            return true;
        } else {
            return false;
        }

    }

    private boolean canFortify() {
        HashMap<String, Integer> countryArmyInfo = player.getCountryArmyInfo();
        if (countryArmyInfo.size() > 1) {
            if (!gameBoard.isGameOver()) {
                int counter = 0;
                for (String countryName : countryArmyInfo.keySet()) {
                    int army = countryArmyInfo.get(countryName) == null ? 0 : countryArmyInfo.get(countryName);
                    if (army > 1) {
                        counter++;
                    }
                }
                if (counter >= 1) {
                    return true;
                } else {
                    return false;
                }
            }
            return false;

        } else {
            return false;
        }

    }

    public Player getPlayer() {
        return player;
    }
    
    public String getSourceCountry(){
        return sourceCountry;
    }
}
